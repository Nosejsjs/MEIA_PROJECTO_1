﻿using System;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormMenuUsuarios : Form
    {
        private Usuario usuario;

        public FormMenuUsuarios(Usuario usuarioLogueado)
        {
            InitializeComponent();
            usuario = usuarioLogueado;
            labelUsuarioNombre7.Text = usuario.NombreUsuario;
            labelNombreNombre7.Text = usuario.Nombre;
            labelApellidoApellido7.Text = usuario.Apellido;
            labelRolUsuario7.Text = usuario.Rol == 1 ? "Administrador" : "Usuario";
            labelEstatusEstatus7.Text = usuario.Estatus == 1 ? "Activo" : "Inactivo";
            labelFecha7.Text = usuario.FechaNacimiento;
            labelTelefonoUsuario7.Text = usuario.Telefono;
        }

        private void buttonModificarDatos7_Click(object sender, EventArgs e)
        {
            var formModificar = new FormModificarDatos(usuario);
            formModificar.Show();
        }

        private void buttonDarBaja7_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("¿Estás seguro de que deseas dar de baja tu cuenta?", "Confirmar Baja", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                string rutaArchivoUsuarios = @"C:/MEIA/user.txt";
                if (!File.Exists(rutaArchivoUsuarios))
                {
                    MessageBox.Show("No se encontró el archivo de usuarios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                string[] lineas = File.ReadAllLines(rutaArchivoUsuarios);
                bool usuarioEncontrado = false;

                for (int i = 0; i < lineas.Length; i++)
                {
                    var datos = lineas[i].Split(';');
                    if (datos[0].Equals(usuario.NombreUsuario, StringComparison.OrdinalIgnoreCase))
                    {
                        datos[7] = "0";
                        lineas[i] = string.Join(';', datos);
                        usuarioEncontrado = true;
                        break;
                    }
                }

                if (usuarioEncontrado)
                {
                    File.WriteAllLines(rutaArchivoUsuarios, lineas);
                    MessageBox.Show("Tu cuenta ha sido dada de baja correctamente.", "Baja Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Application.Restart();
                }
                else
                {
                    MessageBox.Show("No se pudo dar de baja al usuario.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void buttonCerrarSesion7_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}