﻿namespace MEIA_PROYECTO_1
{
    partial class FormModificarDatos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelNuevaContraseña4 = new Label();
            labelNuevaFechaNacimiento4 = new Label();
            labelNuevoTelefono4 = new Label();
            textBoxNuevaContraseña4 = new TextBox();
            textBoxNuevaFechaNacimiento4 = new TextBox();
            textBoxNuevoTelefono4 = new TextBox();
            buttonGuardarCambios4 = new Button();
            SuspendLayout();
            // 
            // labelNuevaContraseña4
            // 
            labelNuevaContraseña4.AutoSize = true;
            labelNuevaContraseña4.Location = new Point(53, 37);
            labelNuevaContraseña4.Name = "labelNuevaContraseña4";
            labelNuevaContraseña4.Size = new Size(102, 15);
            labelNuevaContraseña4.TabIndex = 0;
            labelNuevaContraseña4.Text = "Nueva contraseña";
            // 
            // labelNuevaFechaNacimiento4
            // 
            labelNuevaFechaNacimiento4.AutoSize = true;
            labelNuevaFechaNacimiento4.Location = new Point(53, 111);
            labelNuevaFechaNacimiento4.Name = "labelNuevaFechaNacimiento4";
            labelNuevaFechaNacimiento4.Size = new Size(237, 15);
            labelNuevaFechaNacimiento4.TabIndex = 1;
            labelNuevaFechaNacimiento4.Text = "Nueva Fecha de Nacimiento (dd/mm/aaaa)";
            // 
            // labelNuevoTelefono4
            // 
            labelNuevoTelefono4.AutoSize = true;
            labelNuevoTelefono4.Location = new Point(53, 177);
            labelNuevoTelefono4.Name = "labelNuevoTelefono4";
            labelNuevoTelefono4.Size = new Size(90, 15);
            labelNuevoTelefono4.TabIndex = 2;
            labelNuevoTelefono4.Text = "Nuevo Telefono";
            // 
            // textBoxNuevaContraseña4
            // 
            textBoxNuevaContraseña4.Location = new Point(53, 65);
            textBoxNuevaContraseña4.Name = "textBoxNuevaContraseña4";
            textBoxNuevaContraseña4.Size = new Size(100, 23);
            textBoxNuevaContraseña4.TabIndex = 3;

            // 
            // textBoxNuevaFechaNacimiento4
            // 
            textBoxNuevaFechaNacimiento4.Location = new Point(53, 138);
            textBoxNuevaFechaNacimiento4.Name = "textBoxNuevaFechaNacimiento4";
            textBoxNuevaFechaNacimiento4.Size = new Size(100, 23);
            textBoxNuevaFechaNacimiento4.TabIndex = 4;

            // 
            // textBoxNuevoTelefono4
            // 
            textBoxNuevoTelefono4.Location = new Point(53, 207);
            textBoxNuevoTelefono4.Name = "textBoxNuevoTelefono4";
            textBoxNuevoTelefono4.Size = new Size(100, 23);
            textBoxNuevoTelefono4.TabIndex = 5;

            // 
            // buttonGuardarCambios4
            // 
            buttonGuardarCambios4.Location = new Point(41, 264);
            buttonGuardarCambios4.Name = "buttonGuardarCambios4";
            buttonGuardarCambios4.Size = new Size(126, 23);
            buttonGuardarCambios4.TabIndex = 6;
            buttonGuardarCambios4.Text = "Guardar Cambios";
            buttonGuardarCambios4.UseVisualStyleBackColor = true;
            buttonGuardarCambios4.Click += buttonGuardarCambios4_Click;
            // 
            // FormModificarDatos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(306, 316);
            Controls.Add(buttonGuardarCambios4);
            Controls.Add(textBoxNuevoTelefono4);
            Controls.Add(textBoxNuevaFechaNacimiento4);
            Controls.Add(textBoxNuevaContraseña4);
            Controls.Add(labelNuevoTelefono4);
            Controls.Add(labelNuevaFechaNacimiento4);
            Controls.Add(labelNuevaContraseña4);
            Name = "FormModificarDatos";
            Text = "Modificar Datos";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelNuevaContraseña4;
        private Label labelNuevaFechaNacimiento4;
        private Label labelNuevoTelefono4;
        private TextBox textBoxNuevaContraseña4;
        private TextBox textBoxNuevaFechaNacimiento4;
        private TextBox textBoxNuevoTelefono4;
        private Button buttonGuardarCambios4;
    }
}