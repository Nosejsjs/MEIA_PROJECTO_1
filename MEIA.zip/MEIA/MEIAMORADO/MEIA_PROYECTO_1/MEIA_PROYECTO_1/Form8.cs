﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormContacto : Form
    {
        private const string RutaContactos = "C:/MEIA/contactos.txt";
        private const string RutaUsuarios = "C:/MEIA/user.txt";
        private string contactoSeleccionado; // Almacena la línea completa del contacto seleccionado para su eliminación

        public FormContacto()
        {
            InitializeComponent();
            LimpiarLabelsContacto(); // Mantener campos vacíos al iniciar
        }

        private void buttonBuscarUsuario8_Click(object sender, EventArgs e)
        {
            string busqueda = textBoxBusquedaUsuario8.Text;
            string criterio = comboBoxBusqueda8.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(criterio))
            {
                MessageBox.Show("Por favor, seleccione un criterio de búsqueda.");
                return;
            }

            BuscarUsuario(busqueda, criterio);
        }

        private void BuscarUsuario(string busqueda, string criterio)
        {
            try
            {
                var lineasUsuarios = File.ReadAllLines(RutaUsuarios);
                int indexCriterio = GetIndexByCriterio(criterio);

                if (indexCriterio == -1)
                {
                    MessageBox.Show("Criterio de búsqueda inválido.");
                    return;
                }

                var usuarioEncontrado = lineasUsuarios.FirstOrDefault(linea =>
                {
                    var datos = linea.Split(';');
                    return datos[indexCriterio].Equals(busqueda, StringComparison.OrdinalIgnoreCase);
                });

                if (usuarioEncontrado != null)
                {
                    var datos = usuarioEncontrado.Split(';');
                    labelShowUsuarioUser8.Text = datos[0];   // Nombre de usuario
                    labelShowNombreUser8.Text = datos[1];     // Nombre
                    labelShowApellidoUser8.Text = datos[2];   // Apellido
                }
                else
                {
                    MessageBox.Show("Usuario no encontrado en la lista de usuarios.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar el usuario: {ex.Message}");
            }
        }

        private int GetIndexByCriterio(string criterio)
        {
            return criterio switch
            {
                "Usuario" => 0,
                "Nombre" => 1,
                "Apellido" => 2,
                _ => -1
            };
        }

        private void buttonAgregarContacto_Click(object sender, EventArgs e)
        {
            string contacto = textBoxBusquedaUsuario8.Text;
            if (string.IsNullOrEmpty(contacto))
            {
                MessageBox.Show("Ingrese un nombre de contacto para agregar.");
                return;
            }

            if (!UsuarioExiste(contacto))
            {
                MessageBox.Show("El usuario no existe en la lista de usuarios.");
                return;
            }

            string fechaHoraActual = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string estatus = "1"; // 1 representa "activo"
            string nombreUsuarioTransaccion = textBoxUsuarioTransaccion.Text; // Obtiene el usuario ingresado en el textbox
            string nuevoContacto = $"{contacto};{labelShowNombreUser8.Text};{fechaHoraActual};{nombreUsuarioTransaccion};{estatus}";

            try
            {
                using (StreamWriter sw = File.AppendText(RutaContactos))
                {
                    sw.WriteLine(nuevoContacto);
                }
                MessageBox.Show("Contacto agregado correctamente.");
                textBoxBusquedaUsuario8.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al agregar el contacto: {ex.Message}");
            }
        }

        private void buttonBuscarContacto8_Click(object sender, EventArgs e)
        {
            string busquedaContacto = textBoxBusquedaContacto8.Text;
            if (string.IsNullOrEmpty(busquedaContacto))
            {
                MessageBox.Show("Ingrese el nombre del contacto para buscar.");
                return;
            }

            BuscarContacto(busquedaContacto);
        }

        private void BuscarContacto(string nombreContacto)
        {
            try
            {
                var lineasContactos = File.ReadAllLines(RutaContactos);
                var contactoEncontrado = lineasContactos.FirstOrDefault(linea =>
                {
                    var datos = linea.Split(';');
                    return datos[0].Equals(nombreContacto, StringComparison.OrdinalIgnoreCase);
                });

                if (contactoEncontrado != null)
                {
                    var datos = contactoEncontrado.Split(';');
                    MostrarContactoEnPantalla(datos[0], datos[1], datos[2], datos[3], datos[4]);
                }
                else
                {
                    MessageBox.Show("Contacto no encontrado.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar el contacto: {ex.Message}");
            }
        }

        private void MostrarContactoEnPantalla(string usuario, string nombre, string fecha, string usuarioTransaccion, string estatus)
        {
            labelShowUsuarioContacto8.Text = usuario;
            labelShowNombreContacto8.Text = nombre;
            labelShowFechaContacto8.Text = fecha;
            labelShowUsuarioTrans8.Text = usuarioTransaccion;
            labelShowEstatusContacto8.Text = estatus == "1" ? "Activo" : "Inactivo";
            contactoSeleccionado = $"{usuario};{nombre};{fecha};{usuarioTransaccion};{estatus}";
        }

        private bool UsuarioExiste(string nombreUsuario)
        {
            try
            {
                return File.ReadAllLines(RutaUsuarios).Any(linea => linea.Split(';')[0].Equals(nombreUsuario, StringComparison.OrdinalIgnoreCase));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al verificar si el usuario existe: {ex.Message}");
                return false;
            }
        }

        private void buttonEliminarContacto8_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(contactoSeleccionado))
            {
                MessageBox.Show("Primero busque y seleccione un contacto antes de eliminar.");
                return;
            }

            EliminarContacto(contactoSeleccionado);
        }

        private void EliminarContacto(string contacto)
        {
            try
            {
                var lineas = File.ReadAllLines(RutaContactos).ToList();
                if (lineas.Remove(contacto))
                {
                    File.WriteAllLines(RutaContactos, lineas);
                    MessageBox.Show("Contacto eliminado correctamente.");
                    LimpiarLabelsContacto();
                    contactoSeleccionado = null;
                }
                else
                {
                    MessageBox.Show("No se encontró el contacto a eliminar.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar el contacto: {ex.Message}");
            }
        }

        private void LimpiarLabelsContacto()
        {
            labelShowUsuarioContacto8.Text = "...";
            labelShowNombreContacto8.Text = "...";
            labelShowFechaContacto8.Text = "...";
            labelShowUsuarioTrans8.Text = "...";
            labelShowEstatusContacto8.Text = "...";
        }

        private void buttonModificarContacto_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(contactoSeleccionado))
            {
                FormModificarContacto formModificar = new FormModificarContacto(contactoSeleccionado);
                formModificar.ShowDialog();
            }
            else
            {
                MessageBox.Show("Seleccione un contacto para modificar.");
            }
        }

        private void textBoxUsuarioTransaccion_TextChanged(object sender, EventArgs e)
        {
            // Este método puede ser usado para cualquier lógica que quieras agregar cuando el usuario cambie el texto en el textboxUsuarioTransaccion.
        }

        private void buttonModificarContacto_Click_1(object sender, EventArgs e)
        {
            var formModificarContacto = new FormModificarContacto(contactoSeleccionado);
            formModificarContacto.Show();
        }
    }
}