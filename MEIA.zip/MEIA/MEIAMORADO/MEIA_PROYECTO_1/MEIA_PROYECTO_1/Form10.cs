﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormListas : Form
    {
        private const string RutaListas = "C:/MEIA/listas.txt"; // Ruta del archivo de listas

        public FormListas()
        {
            InitializeComponent();
        }

        private void buttonCrearLista10_Click(object sender, EventArgs e)
        {
            string nombreLista = textBoxNombre10.Text;
            string descripcionLista = textBoxDesc10.Text;
            string usuarioActual = textBoxUsuarioActual.Text; // Usuario que crea la lista

            if (string.IsNullOrEmpty(nombreLista) || string.IsNullOrEmpty(descripcionLista))
            {
                MessageBox.Show("Por favor, ingrese el nombre y la descripción de la lista.");
                return;
            }

            // Validar si la lista ya existe
            var listas = File.ReadLines(RutaListas);
            if (listas.Any(linea => linea.Split(';')[0] == nombreLista))
            {
                MessageBox.Show("Ya existe una lista con ese nombre.");
                return;
            }

            // Construir la nueva lista con los datos adicionales
            string nuevaLista = $"{nombreLista};{usuarioActual};{descripcionLista};0;{DateTime.Now};Activo"; // Inicialmente como Activo
            File.AppendAllText(RutaListas, nuevaLista + Environment.NewLine);

            MessageBox.Show("Lista creada correctamente.");
            LimpiarCampos();
        }

        private void buttonBuscarLista10_Click(object sender, EventArgs e)
        {
            string nombreListaBuscar = textBoxBuscar10.Text;

            if (string.IsNullOrEmpty(nombreListaBuscar))
            {
                MessageBox.Show("Por favor, ingrese el nombre de la lista a buscar.");
                return;
            }

            var listas = File.ReadLines(RutaListas);
            var listaEncontrada = listas.FirstOrDefault(linea => linea.Split(';')[0] == nombreListaBuscar);

            if (listaEncontrada != null)
            {
                // Dividir la línea encontrada por el delimitador ';'
                var datosLista = listaEncontrada.Split(';');
                string mensaje = $"Nombre: {datosLista[0]}\n" +
                                 $"Usuario: {datosLista[1]}\n" +
                                 $"Descripción: {datosLista[2]}\n" +
                                 $"Número de usuarios: {datosLista[3]}\n" +
                                 $"Fecha de creación: {datosLista[4]}\n" +
                                 $"Estatus: {datosLista[5]}";

                MessageBox.Show(mensaje, "Detalles de la Lista");
            }
            else
            {
                MessageBox.Show("Lista no encontrada.");
            }
        }

        private void buttonModificarLista10_Click(object sender, EventArgs e)
        {
            string nombreListaModificar = textBoxModificar10.Text;

            if (string.IsNullOrEmpty(nombreListaModificar))
            {
                MessageBox.Show("Por favor, ingrese el nombre de la lista a modificar.");
                return;
            }

            var listas = File.ReadLines(RutaListas).ToList();
            var listaEncontrada = listas.FirstOrDefault(linea => linea.Split(';')[0] == nombreListaModificar);

            if (listaEncontrada != null)
            {
                var formModificarLista = new FormModificarLista(listaEncontrada);
                formModificarLista.ShowDialog(); // Modal para asegurarnos de que se modifica antes de continuar
            }
            else
            {
                MessageBox.Show("Lista no encontrada.");
            }
        }

        private void LimpiarCampos()
        {
            textBoxNombre10.Clear();
            textBoxDesc10.Clear();
            textBoxBuscar10.Clear();
            textBoxModificar10.Clear();
            textBoxUsuarioActual.Clear(); // Limpiar el campo de usuario actual
        }
    }
}





