﻿namespace MEIA_PROYECTO_1
{
    partial class FormDarBaja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelUsuarioDarBaja6 = new Label();
            textBoxUsuarioDarBaja6 = new TextBox();
            buttonOk6 = new Button();
            buttonCancelar6 = new Button();
            SuspendLayout();
            // 
            // labelUsuarioDarBaja6
            // 
            labelUsuarioDarBaja6.AutoSize = true;
            labelUsuarioDarBaja6.Location = new Point(60, 47);
            labelUsuarioDarBaja6.Name = "labelUsuarioDarBaja6";
            labelUsuarioDarBaja6.Size = new Size(182, 15);
            labelUsuarioDarBaja6.TabIndex = 0;
            labelUsuarioDarBaja6.Text = "Introduce el usuario a dar de baja";
            // 
            // textBoxUsuarioDarBaja6
            // 
            textBoxUsuarioDarBaja6.Location = new Point(60, 65);
            textBoxUsuarioDarBaja6.Name = "textBoxUsuarioDarBaja6";
            textBoxUsuarioDarBaja6.Size = new Size(182, 23);
            textBoxUsuarioDarBaja6.TabIndex = 1;

            // 
            // buttonOk6
            // 
            buttonOk6.Location = new Point(60, 94);
            buttonOk6.Name = "buttonOk6";
            buttonOk6.Size = new Size(75, 23);
            buttonOk6.TabIndex = 2;
            buttonOk6.Text = "OK";
            buttonOk6.UseVisualStyleBackColor = true;
            buttonOk6.Click += buttonOk6_Click;
            // 
            // buttonCancelar6
            // 
            buttonCancelar6.Location = new Point(167, 94);
            buttonCancelar6.Name = "buttonCancelar6";
            buttonCancelar6.Size = new Size(75, 23);
            buttonCancelar6.TabIndex = 3;
            buttonCancelar6.Text = "Cancelar";
            buttonCancelar6.UseVisualStyleBackColor = true;
            buttonCancelar6.Click += buttonCancelar6_Click;
            // 
            // FormDarBaja
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(311, 170);
            Controls.Add(buttonCancelar6);
            Controls.Add(buttonOk6);
            Controls.Add(textBoxUsuarioDarBaja6);
            Controls.Add(labelUsuarioDarBaja6);
            Name = "FormDarBaja";
            Text = "Dar de Baja";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelUsuarioDarBaja6;
        private TextBox textBoxUsuarioDarBaja6;
        private Button buttonOk6;
        private Button buttonCancelar6;
    }
}