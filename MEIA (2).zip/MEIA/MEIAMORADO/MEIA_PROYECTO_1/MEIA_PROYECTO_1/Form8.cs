﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormContacto : Form
    {
        public FormContacto()
        {
            InitializeComponent();
        }

        private void FormContacto_Load(object sender, EventArgs e)
        {
            // Opcional: Cargar datos iniciales o preparar elementos de la interfaz al cargar el formulario
        }

        private void textBoxBusqueda8_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
