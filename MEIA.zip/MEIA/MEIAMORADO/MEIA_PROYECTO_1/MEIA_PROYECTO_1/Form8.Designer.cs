﻿namespace MEIA_PROYECTO_1
{
    partial class FormContacto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxContacto8 = new TextBox();
            labelContacto8 = new Label();
            labelUsuarioTransaccion8 = new Label();
            buttonAgregarContacto8 = new Button();
            buttonEliminarContacto8 = new Button();
            buttonBuscarContacto8 = new Button();
            SuspendLayout();
            // 
            // textBoxContacto8
            // 
            textBoxContacto8.Location = new Point(72, 12);
            textBoxContacto8.Name = "textBoxContacto8";
            textBoxContacto8.Size = new Size(144, 23);
            textBoxContacto8.TabIndex = 1;
            textBoxContacto8.TextChanged += textBoxContacto8_TextChanged;
            // 
            // labelContacto8
            // 
            labelContacto8.AutoSize = true;
            labelContacto8.Location = new Point(10, 15);
            labelContacto8.Name = "labelContacto8";
            labelContacto8.Size = new Size(56, 15);
            labelContacto8.TabIndex = 4;
            labelContacto8.Text = "Contacto";
            // 
            // labelUsuarioTransaccion8
            // 
            labelUsuarioTransaccion8.AutoSize = true;
            labelUsuarioTransaccion8.Location = new Point(272, 22);
            labelUsuarioTransaccion8.Name = "labelUsuarioTransaccion8";
            labelUsuarioTransaccion8.Size = new Size(0, 15);
            labelUsuarioTransaccion8.TabIndex = 5;
            // 
            // buttonAgregarContacto8
            // 
            buttonAgregarContacto8.Location = new Point(222, 12);
            buttonAgregarContacto8.Name = "buttonAgregarContacto8";
            buttonAgregarContacto8.Size = new Size(114, 25);
            buttonAgregarContacto8.TabIndex = 6;
            buttonAgregarContacto8.Text = "agregar contacto";
            buttonAgregarContacto8.UseVisualStyleBackColor = true;
            buttonAgregarContacto8.Click += buttonAgregarContacto8_Click;
            // 
            // buttonEliminarContacto8
            // 
            buttonEliminarContacto8.Location = new Point(342, 12);
            buttonEliminarContacto8.Name = "buttonEliminarContacto8";
            buttonEliminarContacto8.Size = new Size(116, 25);
            buttonEliminarContacto8.TabIndex = 7;
            buttonEliminarContacto8.Text = "Eliminar contacto";
            buttonEliminarContacto8.UseVisualStyleBackColor = true;
            buttonEliminarContacto8.Click += buttonEliminarContacto8_Click;
            // 
            // buttonBuscarContacto8
            // 
            buttonBuscarContacto8.Location = new Point(464, 12);
            buttonBuscarContacto8.Name = "buttonBuscarContacto8";
            buttonBuscarContacto8.Size = new Size(111, 25);
            buttonBuscarContacto8.TabIndex = 9;
            buttonBuscarContacto8.Text = "Buscar Contacto";
            buttonBuscarContacto8.UseVisualStyleBackColor = true;
            // 
            // FormContacto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(589, 51);
            Controls.Add(buttonBuscarContacto8);
            Controls.Add(buttonEliminarContacto8);
            Controls.Add(buttonAgregarContacto8);
            Controls.Add(labelUsuarioTransaccion8);
            Controls.Add(labelContacto8);
            Controls.Add(textBoxContacto8);
            Name = "FormContacto";
            Text = "FormContacto";
            Load += FormContacto_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBoxContacto8;
        private Label labelContacto8;
        private Label labelUsuarioTransaccion8;
        private Button buttonAgregarContacto8;
        private Button buttonEliminarContacto8;
        private Button buttonBuscarContacto8;
        private ListBox listBox1;
    }
}