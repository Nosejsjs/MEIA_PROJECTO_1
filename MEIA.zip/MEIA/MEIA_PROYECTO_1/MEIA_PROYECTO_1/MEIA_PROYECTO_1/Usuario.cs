﻿using System;

namespace MEIA_PROYECTO_1
{
    public class Usuario
    {
        public string NombreUsuario { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Contraseña { get; set; }
        public int Rol { get; set; } // 1 = admin, 0 = Usuario normal
        public string FechaNacimiento { get; set; }
        public string Telefono { get; set; }
        public int Estatus { get; set; } // 1 = Activoo, 0 = Inactivo
    }
}
