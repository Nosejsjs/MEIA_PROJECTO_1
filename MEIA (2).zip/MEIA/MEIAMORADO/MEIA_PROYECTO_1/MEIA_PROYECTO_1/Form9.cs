﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormListaDifusion : Form
    {
        private string usuarioActual;

        public FormListaDifusion(string usuario)
        {
            InitializeComponent();
            usuarioActual = usuario;
        }

        private void FormListaDifusion_Load(object sender, EventArgs e)
        {
            // Opcional: Cargar datos iniciales o preparar la interfaz al cargar el formulario
        }

        private bool ContactoExiste(string contacto)
        {
            var lineasContacto = File.ReadAllLines("C:/MEIA/contactos.txt");
            return lineasContacto.Any(linea => linea.StartsWith($"{usuarioActual}:{contacto}"));
        }

        private void buttonAgregar9_Click(object sender, EventArgs e)
        {
            string contacto = textBoxAgregar9.Text;
            if (!string.IsNullOrEmpty(contacto))
            {
                if (ContactoExiste(contacto))
                {
                    string linea = $"{usuarioActual}:{contacto}";
                    using (StreamWriter sw = File.AppendText("C:/MEIA/lista.txt"))
                    {
                        sw.WriteLine(linea);
                    }
                    MessageBox.Show("Contacto agregado a la lista de difusión.");
                    textBoxAgregar9.Clear();
                }
                else
                {
                    MessageBox.Show("El contacto no está registrado en la lista de contactos.");
                }
            }
            else
            {
                MessageBox.Show("Ingrese un nombre de contacto.");
            }
        }

        private void buttonEliminar9_Click(object sender, EventArgs e)
        {
            string contactoAEliminar = textBoxAgregar9.Text;
            if (string.IsNullOrEmpty(contactoAEliminar))
            {
                MessageBox.Show("Ingrese el nombre del contacto a eliminar.");
                return;
            }

            var lineas = File.ReadAllLines("C:/MEIA/lista.txt").ToList();
            string lineaAEliminar = $"{usuarioActual}:{contactoAEliminar}";

            if (lineas.Contains(lineaAEliminar))
            {
                lineas.Remove(lineaAEliminar);
                File.WriteAllLines("C:/MEIA/lista.txt", lineas);
                MessageBox.Show("Contacto eliminado de la lista de difusión.");
                textBoxAgregar9.Clear();
            }
            else
            {
                MessageBox.Show("Contacto no encontrado en la lista.");
            }
        }

        private void buttonBuscar9_Click(object sender, EventArgs e)
        {
            string contactoABuscar = textBoxAgregar9.Text;
            string lineaABuscar = $"{usuarioActual}:{contactoABuscar}";
            var lineas = File.ReadAllLines("C:/MEIA/lista.txt");

            if (lineas.Contains(lineaABuscar))
            {
                MessageBox.Show("Contacto encontrado en la lista de difusión.");
            }
            else
            {
                MessageBox.Show("Contacto no encontrado en la lista de difusión.");
            }
        }

        private void textBoxAgregar9_TextChanged(object sender, EventArgs e)
        {
            // Opcional: Agregar funcionalidades adicionales cuando se cambia el texto, si es necesario
        }
    }
}

