﻿namespace MEIA_PROYECTO_1
{
    partial class FormContacto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelUsuarioTransaccion8 = new Label();
            textBoxBusqueda8 = new TextBox();
            comboBoxBusqueda8 = new ComboBox();
            buttonBuscar8 = new Button();
            dataGridView1 = new DataGridView();
            Usuario = new DataGridViewTextBoxColumn();
            Contacto = new DataGridViewTextBoxColumn();
            Fecha = new DataGridViewTextBoxColumn();
            UsuarioTrans = new DataGridViewTextBoxColumn();
            Estatus = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // labelUsuarioTransaccion8
            // 
            labelUsuarioTransaccion8.AutoSize = true;
            labelUsuarioTransaccion8.Location = new Point(272, 22);
            labelUsuarioTransaccion8.Name = "labelUsuarioTransaccion8";
            labelUsuarioTransaccion8.Size = new Size(0, 15);
            labelUsuarioTransaccion8.TabIndex = 5;
            // 
            // textBoxBusqueda8
            // 
            textBoxBusqueda8.Location = new Point(12, 12);
            textBoxBusqueda8.Name = "textBoxBusqueda8";
            textBoxBusqueda8.Size = new Size(100, 23);
            textBoxBusqueda8.TabIndex = 6;
            textBoxBusqueda8.TextChanged += textBoxBusqueda8_TextChanged;
            // 
            // comboBoxBusqueda8
            // 
            comboBoxBusqueda8.FormattingEnabled = true;
            comboBoxBusqueda8.Items.AddRange(new object[] { "Usuario", "Nombre", "Apellidos" });
            comboBoxBusqueda8.Location = new Point(118, 12);
            comboBoxBusqueda8.Name = "comboBoxBusqueda8";
            comboBoxBusqueda8.Size = new Size(121, 23);
            comboBoxBusqueda8.TabIndex = 7;
            // 
            // buttonBuscar8
            // 
            buttonBuscar8.Location = new Point(245, 12);
            buttonBuscar8.Name = "buttonBuscar8";
            buttonBuscar8.Size = new Size(75, 23);
            buttonBuscar8.TabIndex = 8;
            buttonBuscar8.Text = "Buscar";
            buttonBuscar8.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Usuario, Contacto, Fecha, UsuarioTrans, Estatus });
            dataGridView1.Location = new Point(2, 51);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(581, 313);
            dataGridView1.TabIndex = 9;
            // 
            // Usuario
            // 
            Usuario.HeaderText = "Usuario";
            Usuario.Name = "Usuario";
            // 
            // Contacto
            // 
            Contacto.HeaderText = "Contacto";
            Contacto.Name = "Contacto";
            // 
            // Fecha
            // 
            Fecha.HeaderText = "Fecha de transaccion";
            Fecha.Name = "Fecha";
            // 
            // UsuarioTrans
            // 
            UsuarioTrans.HeaderText = "Usuario transaccion";
            UsuarioTrans.Name = "UsuarioTrans";
            // 
            // Estatus
            // 
            Estatus.HeaderText = "Estatus";
            Estatus.Name = "Estatus";
            // 
            // FormContacto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(585, 423);
            Controls.Add(dataGridView1);
            Controls.Add(buttonBuscar8);
            Controls.Add(comboBoxBusqueda8);
            Controls.Add(textBoxBusqueda8);
            Controls.Add(labelUsuarioTransaccion8);
            Name = "FormContacto";
            Text = "FormContacto";
            Load += FormContacto_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label labelUsuarioTransaccion8;
        private ListBox listBox1;
        private TextBox textBoxBusqueda8;
        private ComboBox comboBoxBusqueda8;
        private Button buttonBuscar8;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Usuario;
        private DataGridViewTextBoxColumn Contacto;
        private DataGridViewTextBoxColumn Fecha;
        private DataGridViewTextBoxColumn UsuarioTrans;
        private DataGridViewTextBoxColumn Estatus;
    }
}