﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormContacto : Form
    {
        public FormContacto()
        {
            InitializeComponent();
        }

        private void FormContacto_Load(object sender, EventArgs e)
        {

        }

        private void buttonAgregarContacto8_Click(object sender, EventArgs e)
        {
            
        }

        private void textBoxUsuario8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxContacto8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxUsuarioTransaccion8_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonEliminarContacto8_Click(object sender, EventArgs e)
        {
            
        }
    }
}
