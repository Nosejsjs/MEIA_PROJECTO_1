﻿namespace MEIA_PROYECTO_1
{
    partial class FormMenuAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelUsuario2 = new Label();
            labelAdminName = new Label();
            labelRol = new Label();
            labelAdminRol = new Label();
            labelTelefono = new Label();
            labelTelefonoAdmin = new Label();
            buttonNuevoUsuario = new Button();
            buttonModificarDatos = new Button();
            buttonBusquedaUsuarios = new Button();
            buttonRespaldo = new Button();
            buttonDarBaja = new Button();
            buttonCerrarSesion = new Button();
            labelNombre2 = new Label();
            labelNombreNombre2 = new Label();
            labelApellido2 = new Label();
            labelApellidoApellido2 = new Label();
            labelEstatus2 = new Label();
            labelEstatusEstatus = new Label();
            labelFechaNacimiento2 = new Label();
            labelFecha2 = new Label();
            buttonGestionarContactos2 = new Button();
            buttonListasDifusion2 = new Button();
            buttonMantenimientoListas = new Button();
            SuspendLayout();
            // 
            // labelUsuario2
            // 
            labelUsuario2.AutoSize = true;
            labelUsuario2.Location = new Point(27, 43);
            labelUsuario2.Name = "labelUsuario2";
            labelUsuario2.Size = new Size(50, 15);
            labelUsuario2.TabIndex = 0;
            labelUsuario2.Text = "Usuario:";
            // 
            // labelAdminName
            // 
            labelAdminName.AutoSize = true;
            labelAdminName.Location = new Point(100, 43);
            labelAdminName.Name = "labelAdminName";
            labelAdminName.Size = new Size(16, 15);
            labelAdminName.TabIndex = 1;
            labelAdminName.Text = "...";
            // 
            // labelRol
            // 
            labelRol.AutoSize = true;
            labelRol.Location = new Point(27, 107);
            labelRol.Name = "labelRol";
            labelRol.Size = new Size(27, 15);
            labelRol.TabIndex = 2;
            labelRol.Text = "Rol:";
            // 
            // labelAdminRol
            // 
            labelAdminRol.AutoSize = true;
            labelAdminRol.Location = new Point(100, 107);
            labelAdminRol.Name = "labelAdminRol";
            labelAdminRol.Size = new Size(16, 15);
            labelAdminRol.TabIndex = 3;
            labelAdminRol.Text = "...";
            // 
            // labelTelefono
            // 
            labelTelefono.AutoSize = true;
            labelTelefono.Location = new Point(27, 131);
            labelTelefono.Name = "labelTelefono";
            labelTelefono.Size = new Size(55, 15);
            labelTelefono.TabIndex = 4;
            labelTelefono.Text = "Telefono:";
            // 
            // labelTelefonoAdmin
            // 
            labelTelefonoAdmin.AutoSize = true;
            labelTelefonoAdmin.Location = new Point(100, 131);
            labelTelefonoAdmin.Name = "labelTelefonoAdmin";
            labelTelefonoAdmin.Size = new Size(16, 15);
            labelTelefonoAdmin.TabIndex = 5;
            labelTelefonoAdmin.Text = "...";
            // 
            // buttonNuevoUsuario
            // 
            buttonNuevoUsuario.Location = new Point(291, 15);
            buttonNuevoUsuario.Name = "buttonNuevoUsuario";
            buttonNuevoUsuario.Size = new Size(178, 28);
            buttonNuevoUsuario.TabIndex = 6;
            buttonNuevoUsuario.Text = "Registrar Nuevo Usuario";
            buttonNuevoUsuario.UseVisualStyleBackColor = true;
            buttonNuevoUsuario.Click += buttonNuevoUsuario_Click;
            // 
            // buttonModificarDatos
            // 
            buttonModificarDatos.Location = new Point(290, 43);
            buttonModificarDatos.Name = "buttonModificarDatos";
            buttonModificarDatos.Size = new Size(179, 32);
            buttonModificarDatos.TabIndex = 7;
            buttonModificarDatos.Text = "Modificar mis datos";
            buttonModificarDatos.UseVisualStyleBackColor = true;
            buttonModificarDatos.Click += buttonModificarDatos_Click;
            // 
            // buttonBusquedaUsuarios
            // 
            buttonBusquedaUsuarios.Location = new Point(290, 76);
            buttonBusquedaUsuarios.Name = "buttonBusquedaUsuarios";
            buttonBusquedaUsuarios.Size = new Size(179, 31);
            buttonBusquedaUsuarios.TabIndex = 8;
            buttonBusquedaUsuarios.Text = "Busqueda de Usuarios";
            buttonBusquedaUsuarios.UseVisualStyleBackColor = true;
            buttonBusquedaUsuarios.Click += buttonBusquedaUsuarios_Click;
            // 
            // buttonRespaldo
            // 
            buttonRespaldo.Location = new Point(290, 107);
            buttonRespaldo.Name = "buttonRespaldo";
            buttonRespaldo.Size = new Size(179, 29);
            buttonRespaldo.TabIndex = 9;
            buttonRespaldo.Text = "Realizar respaldo";
            buttonRespaldo.UseVisualStyleBackColor = true;
            buttonRespaldo.Click += buttonRespaldo_Click;
            // 
            // buttonDarBaja
            // 
            buttonDarBaja.Location = new Point(291, 136);
            buttonDarBaja.Name = "buttonDarBaja";
            buttonDarBaja.Size = new Size(178, 27);
            buttonDarBaja.TabIndex = 10;
            buttonDarBaja.Text = "Dar de Baja";
            buttonDarBaja.UseVisualStyleBackColor = true;
            buttonDarBaja.Click += buttonDarBaja_Click;
            // 
            // buttonCerrarSesion
            // 
            buttonCerrarSesion.Location = new Point(175, 263);
            buttonCerrarSesion.Name = "buttonCerrarSesion";
            buttonCerrarSesion.Size = new Size(129, 28);
            buttonCerrarSesion.TabIndex = 11;
            buttonCerrarSesion.Text = "Cerrar Sesion";
            buttonCerrarSesion.UseVisualStyleBackColor = true;
            buttonCerrarSesion.Click += buttonCerrarSesion_Click;
            // 
            // labelNombre2
            // 
            labelNombre2.AutoSize = true;
            labelNombre2.Location = new Point(27, 66);
            labelNombre2.Name = "labelNombre2";
            labelNombre2.Size = new Size(54, 15);
            labelNombre2.TabIndex = 12;
            labelNombre2.Text = "Nombre:";
            // 
            // labelNombreNombre2
            // 
            labelNombreNombre2.AutoSize = true;
            labelNombreNombre2.Location = new Point(100, 66);
            labelNombreNombre2.Name = "labelNombreNombre2";
            labelNombreNombre2.Size = new Size(16, 15);
            labelNombreNombre2.TabIndex = 13;
            labelNombreNombre2.Text = "...";
            labelNombreNombre2.Click += labelNombreNombre2_Click;
            // 
            // labelApellido2
            // 
            labelApellido2.AutoSize = true;
            labelApellido2.Location = new Point(27, 88);
            labelApellido2.Name = "labelApellido2";
            labelApellido2.Size = new Size(54, 15);
            labelApellido2.TabIndex = 14;
            labelApellido2.Text = "Apellido:";
            // 
            // labelApellidoApellido2
            // 
            labelApellidoApellido2.AutoSize = true;
            labelApellidoApellido2.Location = new Point(100, 88);
            labelApellidoApellido2.Name = "labelApellidoApellido2";
            labelApellidoApellido2.Size = new Size(16, 15);
            labelApellidoApellido2.TabIndex = 15;
            labelApellidoApellido2.Text = "...";
            labelApellidoApellido2.Click += labelApellidoApellido2_Click;
            // 
            // labelEstatus2
            // 
            labelEstatus2.AutoSize = true;
            labelEstatus2.Location = new Point(27, 152);
            labelEstatus2.Name = "labelEstatus2";
            labelEstatus2.Size = new Size(47, 15);
            labelEstatus2.TabIndex = 16;
            labelEstatus2.Text = "Estatus:";
            // 
            // labelEstatusEstatus
            // 
            labelEstatusEstatus.AutoSize = true;
            labelEstatusEstatus.Location = new Point(99, 154);
            labelEstatusEstatus.Name = "labelEstatusEstatus";
            labelEstatusEstatus.Size = new Size(16, 15);
            labelEstatusEstatus.TabIndex = 17;
            labelEstatusEstatus.Text = "...";
            labelEstatusEstatus.Click += labelEstatusEstatus_Click;
            // 
            // labelFechaNacimiento2
            // 
            labelFechaNacimiento2.AutoSize = true;
            labelFechaNacimiento2.Location = new Point(28, 173);
            labelFechaNacimiento2.Name = "labelFechaNacimiento2";
            labelFechaNacimiento2.Size = new Size(120, 15);
            labelFechaNacimiento2.TabIndex = 18;
            labelFechaNacimiento2.Text = "Fecha de nacimiento:";
            // 
            // labelFecha2
            // 
            labelFecha2.AutoSize = true;
            labelFecha2.Location = new Point(155, 172);
            labelFecha2.Name = "labelFecha2";
            labelFecha2.Size = new Size(16, 15);
            labelFecha2.TabIndex = 19;
            labelFecha2.Text = "...";
            labelFecha2.Click += labelFecha2_Click;
            // 
            // buttonGestionarContactos2
            // 
            buttonGestionarContactos2.Location = new Point(291, 164);
            buttonGestionarContactos2.Name = "buttonGestionarContactos2";
            buttonGestionarContactos2.Size = new Size(178, 23);
            buttonGestionarContactos2.TabIndex = 20;
            buttonGestionarContactos2.Text = "Gestionar Contactos";
            buttonGestionarContactos2.UseVisualStyleBackColor = true;
            buttonGestionarContactos2.Click += buttonGestionarContactos2_Click;
            // 
            // buttonListasDifusion2
            // 
            buttonListasDifusion2.Location = new Point(293, 191);
            buttonListasDifusion2.Name = "buttonListasDifusion2";
            buttonListasDifusion2.Size = new Size(176, 23);
            buttonListasDifusion2.TabIndex = 21;
            buttonListasDifusion2.Text = "listas de difusion";
            buttonListasDifusion2.UseVisualStyleBackColor = true;
            buttonListasDifusion2.Click += buttonListasDifusion2_Click;
            // 
            // buttonMantenimientoListas
            // 
            buttonMantenimientoListas.Location = new Point(294, 216);
            buttonMantenimientoListas.Name = "buttonMantenimientoListas";
            buttonMantenimientoListas.Size = new Size(175, 23);
            buttonMantenimientoListas.TabIndex = 22;
            buttonMantenimientoListas.Text = "Mantenimiento listas-usuario";
            buttonMantenimientoListas.UseVisualStyleBackColor = true;
            buttonMantenimientoListas.Click += buttonMantenimientoListas_Click;
            // 
            // FormMenuAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(510, 303);
            Controls.Add(buttonMantenimientoListas);
            Controls.Add(buttonListasDifusion2);
            Controls.Add(buttonGestionarContactos2);
            Controls.Add(labelFecha2);
            Controls.Add(labelFechaNacimiento2);
            Controls.Add(labelEstatusEstatus);
            Controls.Add(labelEstatus2);
            Controls.Add(labelApellidoApellido2);
            Controls.Add(labelApellido2);
            Controls.Add(labelNombreNombre2);
            Controls.Add(labelNombre2);
            Controls.Add(buttonCerrarSesion);
            Controls.Add(buttonDarBaja);
            Controls.Add(buttonRespaldo);
            Controls.Add(buttonBusquedaUsuarios);
            Controls.Add(buttonModificarDatos);
            Controls.Add(buttonNuevoUsuario);
            Controls.Add(labelTelefonoAdmin);
            Controls.Add(labelTelefono);
            Controls.Add(labelAdminRol);
            Controls.Add(labelRol);
            Controls.Add(labelAdminName);
            Controls.Add(labelUsuario2);
            Name = "FormMenuAdmin";
            Text = "Menu Admin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelUsuario2;
        private Label labelAdminName;
        private Label labelRol;
        private Label labelAdminRol;
        private Label labelTelefono;
        private Label labelTelefonoAdmin;
        private Button buttonNuevoUsuario;
        private Button buttonModificarDatos;
        private Button buttonBusquedaUsuarios;
        private Button buttonRespaldo;
        private Button buttonDarBaja;
        private Button buttonCerrarSesion;
        private Label labelNombre2;
        private Label labelNombreNombre2;
        private Label labelApellido2;
        private Label labelApellidoApellido2;
        private Label labelEstatus2;
        private Label labelEstatusEstatus;
        private Label labelFechaNacimiento2;
        private Label labelFecha2;
        private Button buttonGestionarContactos2;
        private Button buttonListasDifusion2;
        private Button buttonMantenimientoListas;
    }
}