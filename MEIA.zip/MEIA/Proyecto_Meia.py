import os  # Interacción con el sistema operativo (archivos, directorios).
import tkinter as tk  # Biblioteca para interfaces gráficas.
from tkinter import messagebox, filedialog, simpledialog  # Componentes específicos de tkinter para mensajes y diálogos.
from datetime import datetime  # Módulo para trabajar con fechas y horas.

# Directorio base para todos los archivos del sistema
BASE_DIR = "C:/MEIA"

# Archivos utilizados por el sistema
USER_FILE = os.path.join(BASE_DIR, "user.txt")
DESC_USER_FILE = os.path.join(BASE_DIR, "desc_user.txt")
BITACORA_FILE = os.path.join(BASE_DIR, "bitacora_backup.txt")
DESC_BITACORA_FILE = os.path.join(BASE_DIR, "desc_bitacora_backup.txt")

# Función para leer usuarios del archivo
def leer_usuarios():
    usuarios = {}
    if os.path.exists(USER_FILE):
        with open(USER_FILE, 'r') as f:
            for linea in f:
                if linea.strip():
                    user, nombre, apellido, password, rol, fecha_nac, tel, estatus = linea.strip().split(";")
                    usuarios[user] = {
                        "nombre": nombre,
                        "apellido": apellido,
                        "password": password,
                        "rol": int(rol),
                        "fecha_nacimiento": fecha_nac,
                        "telefono": tel,
                        "estatus": int(estatus)
                    }
    return usuarios

# Función para guardar usuarios en el archivo
def guardar_usuarios(usuarios):
    with open(USER_FILE, 'w') as f:
        for user, data in usuarios.items():
            linea = ";".join([user, data["nombre"], data["apellido"], data["password"],
                            str(data["rol"]), data["fecha_nacimiento"], data["telefono"], str(data["estatus"])])
            f.write(linea + "\n")

# Función para verificar credenciales al iniciar sesión
def verificar_credenciales(username, password):
    usuarios = leer_usuarios()
    usuario = usuarios.get(username)
    if usuario and usuario["password"] == password and usuario["estatus"] == 1:
        return usuario
    return None

# Función para actualizar el descriptor de usuarios
def actualizar_desc_user():
    usuarios = leer_usuarios()
    activos = sum(1 for u in usuarios.values() if u["estatus"] == 1)
    inactivos = len(usuarios) - activos
    with open(DESC_USER_FILE, 'w') as f:
        f.write(f"nombre_simbolico: Usuarios\n")
        f.write(f"fecha_creacion: {datetime.now().strftime('%d/%m/%Y')}\n")
        f.write(f"#_registros: {len(usuarios)}\n")
        f.write(f"registros_activos: {activos}\n")
        f.write(f"registros_inactivos: {inactivos}\n")

# Función para realizar respaldo de los archivos del sistema
def respaldo(usuario):
    ruta = filedialog.askdirectory(title="Selecciona la ruta para el respaldo")
    if ruta:
        backup_path = os.path.join(ruta, "MEIA_Backup")
        os.makedirs(backup_path, exist_ok=True)
        for archivo in [USER_FILE, DESC_USER_FILE, BITACORA_FILE, DESC_BITACORA_FILE]:
            if os.path.exists(archivo):
                os.system(f'copy "{archivo}" "{backup_path}"')
        with open(BITACORA_FILE, 'a') as f:
            f.write(f"{backup_path};{usuario};{datetime.now().strftime('%d/%m/%Y')}\n")
        messagebox.showinfo("Éxito", "Respaldo realizado con éxito")

# Función para registrar nuevos usuarios
def registrar_usuario():
    ventana_registro = tk.Toplevel()
    ventana_registro.title("Registrar Usuario")

    campos = ["Usuario", "Nombre", "Apellido", "Contraseña", "Fecha de Nacimiento (dd/mm/aaaa)", "Teléfono"]
    entradas = {}
    
    for campo in campos:
        tk.Label(ventana_registro, text=f"{campo}:").pack()
        entrada = tk.Entry(ventana_registro, show="*" if campo == "Contraseña" else "")
        entrada.pack()
        entradas[campo] = entrada

    def es_primer_usuario():
        return len(leer_usuarios()) == 0  # Si no hay usuarios, el nuevo es el primero

    def guardar_usuario():
        username = entradas["Usuario"].get().strip()
        if username in leer_usuarios():
            messagebox.showerror("Error", "El usuario ya existe.")
            return

        data = {
            "nombre": entradas["Nombre"].get().strip(),
            "apellido": entradas["Apellido"].get().strip(),
            "password": entradas["Contraseña"].get().strip(),
            "rol": 1 if es_primer_usuario() else 0,  # Asignar rol de administrador solo al primer usuario
            "fecha_nacimiento": entradas["Fecha de Nacimiento (dd/mm/aaaa)"].get().strip(),
            "telefono": entradas["Teléfono"].get().strip(),
            "estatus": 1
        }

        usuarios = leer_usuarios()
        usuarios[username] = data
        guardar_usuarios(usuarios)
        messagebox.showinfo("Éxito", "Usuario registrado correctamente")
        ventana_registro.destroy()

    tk.Button(ventana_registro, text="Guardar Usuario", command=guardar_usuario).pack()

# Función para cambiar los datos del administrador
def cambiar_datos_admin(usuario):
    ventana_modificar = tk.Toplevel()
    ventana_modificar.title("Modificar Datos")
    
    campos = ["Nueva Contraseña", "Nueva Fecha de Nacimiento (dd/mm/aaaa)", "Nuevo Teléfono"]
    entradas = {}
    
    for campo in campos:
        tk.Label(ventana_modificar, text=f"{campo}:").pack()
        entrada = tk.Entry(ventana_modificar, show="*" if campo == "Nueva Contraseña" else "")
        entrada.pack()
        entradas[campo] = entrada

    def guardar_cambios():
        usuario.update({
            "password": entradas["Nueva Contraseña"].get(),
            "fecha_nacimiento": entradas["Nueva Fecha de Nacimiento (dd/mm/aaaa)"].get(),
            "telefono": entradas["Nuevo Teléfono"].get()
        })
        usuarios = leer_usuarios()
        usuarios[usuario['nombre']] = usuario  # Asegúrate de utilizar el username correcto
        guardar_usuarios(usuarios)
        messagebox.showinfo("Éxito", "Datos modificados correctamente")
        ventana_modificar.destroy()

    tk.Button(ventana_modificar, text="Guardar Cambios", command=guardar_cambios).pack()

# Función para dar de baja a un usuario
def dar_de_baja(usuario):
    usuarios = leer_usuarios()

    if usuario['rol'] == 1:  # Si es administrador
        # Pedir al administrador que seleccione un usuario
        username = simpledialog.askstring("Dar de Baja", "Introduce el usuario a dar de baja:")
        if username in usuarios:
            del usuarios[username]
            guardar_usuarios(usuarios)
            messagebox.showinfo("Éxito", f"Usuario {username} dado de baja correctamente.")
        else:
            messagebox.showerror("Error", "El usuario no existe.")
    else:  # Si es un usuario normal
        del usuarios[usuario['nombre']]  # Aquí asumimos que el nombre es el username
        guardar_usuarios(usuarios)
        messagebox.showinfo("Éxito", "Tus datos han sido eliminados correctamente.")

# Función para mostrar el menú principal según el rol del usuario
def mostrar_menu(usuario):
    ventana_menu = tk.Tk()
    ventana_menu.title(f"Bienvenido, {usuario['nombre']} {usuario['apellido']}")

    tk.Label(ventana_menu, text=f"Usuario: {usuario['nombre']} {usuario['apellido']}").pack()
    tk.Label(ventana_menu, text=f"Rol: {'Administrador' if usuario['rol'] else 'Usuario'}").pack()
    tk.Label(ventana_menu, text=f"Teléfono: {usuario['telefono']}").pack()

    if usuario["rol"] == 1:  # Administrador
        tk.Button(ventana_menu, text="Registrar Nuevo Usuario", command=registrar_usuario).pack()
        tk.Button(ventana_menu, text="Modificar Mis Datos", command=lambda: cambiar_datos_admin(usuario)).pack()
        tk.Button(ventana_menu, text="Mantenimiento de Usuarios", command=lambda: mantenimiento_usuarios(usuario)).pack()
        tk.Button(ventana_menu, text="Realizar Respaldo", command=lambda: respaldo(usuario["nombre"])).pack()
    else:
        tk.Button(ventana_menu, text="Modificar Mis Datos", command=lambda: cambiar_datos_admin(usuario)).pack()

    # Botón para dar de baja
    tk.Button(ventana_menu, text="Dar de Baja", command=lambda: dar_de_baja(usuario)).pack()

    tk.Button(ventana_menu, text="Cerrar Sesión", command=ventana_menu.destroy).pack()
    ventana_menu.mainloop()

# Función para realizar el mantenimiento de usuarios
def mantenimiento_usuarios(usuario_admin):
    def buscar_usuario():
        username = entrada_buscar.get().strip()
        usuarios = leer_usuarios()
        if username in usuarios:
            messagebox.showinfo("Usuario Encontrado", f"Usuario {username} existe.")
        else:
            messagebox.showerror("Error", "Usuario no encontrado")

    ventana_mantenimiento = tk.Toplevel()
    ventana_mantenimiento.title("Mantenimiento de Usuarios")

    tk.Label(ventana_mantenimiento, text="Buscar Usuario:").pack()
    entrada_buscar = tk.Entry(ventana_mantenimiento)
    entrada_buscar.pack()
    tk.Button(ventana_mantenimiento, text="Buscar", command=buscar_usuario).pack()

# Función principal
def iniciar_sesion():
    username = entrada_usuario.get().strip()
    password = entrada_contraseña.get().strip()
    
    usuario = verificar_credenciales(username, password)
    if usuario:
        mostrar_menu(usuario)
    else:
        messagebox.showerror("Error", "Credenciales incorrectas o usuario inactivo.")

# Ventana de inicio de sesión
ventana_inicio = tk.Tk()
ventana_inicio.title("Iniciar Sesión")

tk.Label(ventana_inicio, text="Usuario:").pack()
entrada_usuario = tk.Entry(ventana_inicio)
entrada_usuario.pack()

tk.Label(ventana_inicio, text="Contraseña:").pack()
entrada_contraseña = tk.Entry(ventana_inicio, show="*")
entrada_contraseña.pack()

tk.Button(ventana_inicio, text="Iniciar Sesión", command=iniciar_sesion).pack()

ventana_inicio.mainloop()
