﻿namespace MEIA_PROYECTO_1
{
    partial class FormMenuUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelUsuario7 = new Label();
            labelUsuarioNombre7 = new Label();
            labelRol7 = new Label();
            labelRolUsuario7 = new Label();
            labelTelefono7 = new Label();
            labelTelefonoUsuario7 = new Label();
            buttonModificarDatos7 = new Button();
            buttonDarBaja7 = new Button();
            buttonCerrarSesion7 = new Button();
            labelNombre7 = new Label();
            labelNombreNombre7 = new Label();
            labelApellido7 = new Label();
            labelApellidoApellido7 = new Label();
            labelEstatus7 = new Label();
            labelEstatusEstatus7 = new Label();
            labelFechaNacimiento7 = new Label();
            labelFecha7 = new Label();
            buttonGestionarContactos7 = new Button();
            SuspendLayout();
            // 
            // labelUsuario7
            // 
            labelUsuario7.AutoSize = true;
            labelUsuario7.Location = new Point(30, 37);
            labelUsuario7.Name = "labelUsuario7";
            labelUsuario7.Size = new Size(59, 15);
            labelUsuario7.TabIndex = 0;
            labelUsuario7.Text = "Usuario 7:";
            // 
            // labelUsuarioNombre7
            // 
            labelUsuarioNombre7.AutoSize = true;
            labelUsuarioNombre7.Location = new Point(107, 37);
            labelUsuarioNombre7.Name = "labelUsuarioNombre7";
            labelUsuarioNombre7.Size = new Size(16, 15);
            labelUsuarioNombre7.TabIndex = 1;
            labelUsuarioNombre7.Text = "...";
            // 
            // labelRol7
            // 
            labelRol7.AutoSize = true;
            labelRol7.Location = new Point(30, 116);
            labelRol7.Name = "labelRol7";
            labelRol7.Size = new Size(27, 15);
            labelRol7.TabIndex = 2;
            labelRol7.Text = "Rol:";
            // 
            // labelRolUsuario7
            // 
            labelRolUsuario7.AutoSize = true;
            labelRolUsuario7.Location = new Point(107, 116);
            labelRolUsuario7.Name = "labelRolUsuario7";
            labelRolUsuario7.Size = new Size(16, 15);
            labelRolUsuario7.TabIndex = 3;
            labelRolUsuario7.Text = "...";
            // 
            // labelTelefono7
            // 
            labelTelefono7.AutoSize = true;
            labelTelefono7.Location = new Point(30, 141);
            labelTelefono7.Name = "labelTelefono7";
            labelTelefono7.Size = new Size(55, 15);
            labelTelefono7.TabIndex = 4;
            labelTelefono7.Text = "Telefono:";
            // 
            // labelTelefonoUsuario7
            // 
            labelTelefonoUsuario7.AutoSize = true;
            labelTelefonoUsuario7.Location = new Point(107, 141);
            labelTelefonoUsuario7.Name = "labelTelefonoUsuario7";
            labelTelefonoUsuario7.Size = new Size(16, 15);
            labelTelefonoUsuario7.TabIndex = 5;
            labelTelefonoUsuario7.Text = "...";
            // 
            // buttonModificarDatos7
            // 
            buttonModificarDatos7.Location = new Point(225, 33);
            buttonModificarDatos7.Name = "buttonModificarDatos7";
            buttonModificarDatos7.Size = new Size(150, 23);
            buttonModificarDatos7.TabIndex = 6;
            buttonModificarDatos7.Text = "Modificar mis datos";
            buttonModificarDatos7.UseVisualStyleBackColor = true;
            buttonModificarDatos7.Click += buttonModificarDatos7_Click;
            // 
            // buttonDarBaja7
            // 
            buttonDarBaja7.Location = new Point(225, 60);
            buttonDarBaja7.Name = "buttonDarBaja7";
            buttonDarBaja7.Size = new Size(150, 23);
            buttonDarBaja7.TabIndex = 7;
            buttonDarBaja7.Text = "Dar de baja";
            buttonDarBaja7.UseVisualStyleBackColor = true;
            buttonDarBaja7.Click += buttonDarBaja7_Click;
            // 
            // buttonCerrarSesion7
            // 
            buttonCerrarSesion7.Location = new Point(153, 259);
            buttonCerrarSesion7.Name = "buttonCerrarSesion7";
            buttonCerrarSesion7.Size = new Size(107, 23);
            buttonCerrarSesion7.TabIndex = 8;
            buttonCerrarSesion7.Text = "Cerrar sesion";
            buttonCerrarSesion7.UseVisualStyleBackColor = true;
            buttonCerrarSesion7.Click += buttonCerrarSesion7_Click;
            // 
            // labelNombre7
            // 
            labelNombre7.AutoSize = true;
            labelNombre7.Location = new Point(30, 67);
            labelNombre7.Name = "labelNombre7";
            labelNombre7.Size = new Size(57, 15);
            labelNombre7.TabIndex = 9;
            labelNombre7.Text = "Nombre: ";
            // 
            // labelNombreNombre7
            // 
            labelNombreNombre7.AutoSize = true;
            labelNombreNombre7.Location = new Point(107, 67);
            labelNombreNombre7.Name = "labelNombreNombre7";
            labelNombreNombre7.Size = new Size(16, 15);
            labelNombreNombre7.TabIndex = 10;
            labelNombreNombre7.Text = "...";
            // 
            // labelApellido7
            // 
            labelApellido7.AutoSize = true;
            labelApellido7.Location = new Point(30, 94);
            labelApellido7.Name = "labelApellido7";
            labelApellido7.Size = new Size(54, 15);
            labelApellido7.TabIndex = 11;
            labelApellido7.Text = "Apellido:";
            // 
            // labelApellidoApellido7
            // 
            labelApellidoApellido7.AutoSize = true;
            labelApellidoApellido7.Location = new Point(107, 94);
            labelApellidoApellido7.Name = "labelApellidoApellido7";
            labelApellidoApellido7.Size = new Size(16, 15);
            labelApellidoApellido7.TabIndex = 12;
            labelApellidoApellido7.Text = "...";
            // 
            // labelEstatus7
            // 
            labelEstatus7.AutoSize = true;
            labelEstatus7.Location = new Point(30, 166);
            labelEstatus7.Name = "labelEstatus7";
            labelEstatus7.Size = new Size(47, 15);
            labelEstatus7.TabIndex = 13;
            labelEstatus7.Text = "Estatus:";
            // 
            // labelEstatusEstatus7
            // 
            labelEstatusEstatus7.AutoSize = true;
            labelEstatusEstatus7.Location = new Point(107, 168);
            labelEstatusEstatus7.Name = "labelEstatusEstatus7";
            labelEstatusEstatus7.Size = new Size(16, 15);
            labelEstatusEstatus7.TabIndex = 14;
            labelEstatusEstatus7.Text = "...";
            // 
            // labelFechaNacimiento7
            // 
            labelFechaNacimiento7.AutoSize = true;
            labelFechaNacimiento7.Location = new Point(28, 191);
            labelFechaNacimiento7.Name = "labelFechaNacimiento7";
            labelFechaNacimiento7.Size = new Size(120, 15);
            labelFechaNacimiento7.TabIndex = 15;
            labelFechaNacimiento7.Text = "Fecha de nacimiento:";
            // 
            // labelFecha7
            // 
            labelFecha7.AutoSize = true;
            labelFecha7.Location = new Point(158, 190);
            labelFecha7.Name = "labelFecha7";
            labelFecha7.Size = new Size(16, 15);
            labelFecha7.TabIndex = 16;
            labelFecha7.Text = "...";
            // 
            // buttonGestionarContactos7
            // 
            buttonGestionarContactos7.Location = new Point(227, 86);
            buttonGestionarContactos7.Name = "buttonGestionarContactos7";
            buttonGestionarContactos7.Size = new Size(148, 23);
            buttonGestionarContactos7.TabIndex = 17;
            buttonGestionarContactos7.Text = "Gestionar Contactos";
            buttonGestionarContactos7.UseVisualStyleBackColor = true;
            buttonGestionarContactos7.Click += buttonGestionarContactos7_Click;
            // 
            // FormMenuUsuarios
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(405, 294);
            Controls.Add(buttonGestionarContactos7);
            Controls.Add(labelFecha7);
            Controls.Add(labelFechaNacimiento7);
            Controls.Add(labelEstatusEstatus7);
            Controls.Add(labelEstatus7);
            Controls.Add(labelApellidoApellido7);
            Controls.Add(labelApellido7);
            Controls.Add(labelNombreNombre7);
            Controls.Add(labelNombre7);
            Controls.Add(buttonCerrarSesion7);
            Controls.Add(buttonDarBaja7);
            Controls.Add(buttonModificarDatos7);
            Controls.Add(labelTelefonoUsuario7);
            Controls.Add(labelTelefono7);
            Controls.Add(labelRolUsuario7);
            Controls.Add(labelRol7);
            Controls.Add(labelUsuarioNombre7);
            Controls.Add(labelUsuario7);
            Name = "FormMenuUsuarios";
            Text = "Menu Usuarios";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelUsuario7;
        private Label labelUsuarioNombre7;
        private Label labelRol7;
        private Label labelRolUsuario7;
        private Label labelTelefono7;
        private Label labelTelefonoUsuario7;
        private Button buttonModificarDatos7;
        private Button buttonDarBaja7;
        private Button buttonCerrarSesion7;
        private Label labelNombre7;
        private Label labelNombreNombre7;
        private Label labelApellido7;
        private Label labelApellidoApellido7;
        private Label labelEstatus7;
        private Label labelEstatusEstatus7;
        private Label labelFechaNacimiento7;
        private Label labelFecha7;
        private Button buttonGestionarContactos7;
    }
}