﻿namespace MEIA_PROYECTO_1
{
    partial class FormListaDifusion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonAgregar9 = new Button();
            buttonBuscar9 = new Button();
            buttonEliminar9 = new Button();
            textBoxAgregar9 = new TextBox();
            SuspendLayout();
            // 
            // buttonAgregar9
            // 
            buttonAgregar9.Location = new Point(178, 85);
            buttonAgregar9.Name = "buttonAgregar9";
            buttonAgregar9.Size = new Size(102, 23);
            buttonAgregar9.TabIndex = 0;
            buttonAgregar9.Text = "agregar a lista";
            buttonAgregar9.UseVisualStyleBackColor = true;
            buttonAgregar9.Click += buttonAgregar9_Click;
            // 
            // buttonBuscar9
            // 
            buttonBuscar9.Location = new Point(178, 56);
            buttonBuscar9.Name = "buttonBuscar9";
            buttonBuscar9.Size = new Size(102, 23);
            buttonBuscar9.TabIndex = 1;
            buttonBuscar9.Text = "buscar contacto";
            buttonBuscar9.UseVisualStyleBackColor = true;
            buttonBuscar9.Click += buttonBuscar9_Click;
            // 
            // buttonEliminar9
            // 
            buttonEliminar9.Location = new Point(178, 114);
            buttonEliminar9.Name = "buttonEliminar9";
            buttonEliminar9.Size = new Size(102, 23);
            buttonEliminar9.TabIndex = 3;
            buttonEliminar9.Text = "eliminar de lista";
            buttonEliminar9.UseVisualStyleBackColor = true;
            buttonEliminar9.Click += buttonEliminar9_Click;
            // 
            // textBoxAgregar9
            // 
            textBoxAgregar9.Location = new Point(53, 85);
            textBoxAgregar9.Name = "textBoxAgregar9";
            textBoxAgregar9.Size = new Size(100, 23);
            textBoxAgregar9.TabIndex = 4;
            textBoxAgregar9.TextChanged += textBoxAgregar9_TextChanged;
            // 
            // FormListaDifusion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(314, 193);
            Controls.Add(textBoxAgregar9);
            Controls.Add(buttonEliminar9);
            Controls.Add(buttonBuscar9);
            Controls.Add(buttonAgregar9);
            Name = "FormListaDifusion";
            Text = "FormListaDifusion";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonAgregar9;
        private Button buttonBuscar9;
        private Button buttonEliminar9;
        private TextBox textBoxAgregar9;
    }
}