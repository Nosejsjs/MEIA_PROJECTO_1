﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormModificarLista : Form
    {
        private const string RutaListas = "C:/MEIA/listas.txt";
        private string listaSeleccionada;

        public FormModificarLista(string lista)
        {
            InitializeComponent();
            listaSeleccionada = lista;
        }

        private void FormModificarLista_Load(object sender, EventArgs e)
        {
            CargarDatosLista();
        }

        private void CargarDatosLista()
        {
            // Cargar los datos de la lista seleccionada en los TextBox
            var datos = listaSeleccionada.Split(';');
            textBoxNuevoNombre11.Text = datos[0]; // Nombre de la lista
            textBoxNuevaDesc11.Text = datos[2];  // Descripción de la lista

            // Establecer el valor del ComboBox según el estatus
            comboBoxEstatus.SelectedItem = datos[5] == "Activo" ? "Activo" : "Inactivo"; // Estatus
        }

        private void buttonModificar11_Click(object sender, EventArgs e)
        {
            try
            {
                // Leer todas las líneas del archivo
                var listas = File.ReadLines(RutaListas).ToList();

                // Buscar la línea que corresponde a la lista seleccionada
                for (int i = 0; i < listas.Count; i++)
                {
                    var datos = listas[i].Split(';');
                    if (datos[0] == listaSeleccionada.Split(';')[0]) // Compara el nombre de la lista
                    {
                        // Obtener el nuevo nombre, descripción y estatus
                        string nuevoNombre = textBoxNuevoNombre11.Text;
                        string nuevaDescripcion = textBoxNuevaDesc11.Text;

                        // Establecer el nuevo estatus desde el ComboBox
                        string nuevoEstatus = comboBoxEstatus.SelectedItem.ToString() == "Activo" ? "Activo" : "Inactivo";

                        // Modificar la lista seleccionada con los nuevos datos
                        listas[i] = $"{nuevoNombre};{datos[1]};{nuevaDescripcion};{datos[3]};{DateTime.Now};{nuevoEstatus}"; // Se preservan otros datos (como el número de usuarios)

                        break;
                    }
                }

                // Guardar las líneas actualizadas de nuevo en el archivo
                File.WriteAllLines(RutaListas, listas);
                MessageBox.Show("Lista modificada correctamente.");
                this.Close(); // Cerrar el formulario después de la modificación
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error al modificar la lista: {ex.Message}");
            }
        }
    }
}

