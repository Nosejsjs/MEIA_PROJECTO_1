﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormModificarContacto : Form
    {
        private const string RutaContactos = "C:/MEIA/contactos.txt";
        private string contactoSeleccionado;
        private string estatusActual;

        public FormModificarContacto(string contacto)
        {
            InitializeComponent();
            contactoSeleccionado = contacto;
        }

        private void FormModificarContacto_Load(object sender, EventArgs e)
        {
            CargarDatosContacto();
        }

        private void CargarDatosContacto()
        {
            if (string.IsNullOrEmpty(contactoSeleccionado)) return;

            var datos = contactoSeleccionado.Split(';');
            textBoxNombre9.Text = datos[0]; // Nombre del contacto actual
            estatusActual = datos[4] == "1" ? "Activo" : "Inactivo"; // Estado actual
        }

        private void buttonEstatus9_Click(object sender, EventArgs e)
        {
            // Cambiar el estatus y mostrar el mensaje emergente
            estatusActual = estatusActual == "Activo" ? "Inactivo" : "Activo";
            MessageBox.Show($"El contacto ahora está: {estatusActual}");

            // Guardar cambios automáticamente cuando se cambia el estatus
            GuardarCambios();
        }

        private void buttonNombre9_Click(object sender, EventArgs e)
        {
            // Cambiar el nombre solo si no está vacío
            if (!string.IsNullOrEmpty(textBoxNombre9.Text))
            {
                // Mostrar un mensaje emergente con el nuevo nombre
                MessageBox.Show($"El nombre del contacto se cambió a: {textBoxNombre9.Text}");

                // Guardar el cambio de nombre automáticamente
                GuardarCambios();
            }
            else
            {
                MessageBox.Show("El nombre no puede estar vacío.");
            }

            // Cerrar la ventana después de mostrar el mensaje
            this.Close();
        }

        private void GuardarCambios()
        {
            try
            {
                var lineasContactos = File.ReadAllLines(RutaContactos).ToList();
                var index = lineasContactos.FindIndex(linea => linea.Equals(contactoSeleccionado));

                if (index != -1)
                {
                    // Crear una nueva línea con los datos actualizados del contacto
                    var datos = contactoSeleccionado.Split(';');
                    datos[0] = textBoxNombre9.Text; // Actualizar el nombre
                    datos[4] = estatusActual == "Activo" ? "1" : "0"; // Actualizar estatus (1: Activo, 0: Inactivo)

                    // Construir la línea actualizada
                    string lineaActualizada = string.Join(";", datos);

                    // Reemplazar la línea en la lista con la línea actualizada
                    lineasContactos[index] = lineaActualizada;

                    // Guardar todas las líneas de nuevo en el archivo
                    File.WriteAllLines(RutaContactos, lineasContactos);
                }
                else
                {
                    MessageBox.Show("No se encontró el contacto a modificar.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al modificar el contacto: {ex.Message}");
            }
        }
    }
}
