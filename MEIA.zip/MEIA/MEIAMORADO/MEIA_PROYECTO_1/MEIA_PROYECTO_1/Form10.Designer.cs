﻿namespace MEIA_PROYECTO_1
{
    partial class FormListas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonCrearLista10 = new Button();
            buttonModificarLista10 = new Button();
            buttonBuscarLista10 = new Button();
            labelNombrelista10 = new Label();
            labelDescrip10 = new Label();
            textBoxNombre10 = new TextBox();
            textBoxDesc10 = new TextBox();
            textBoxBuscar10 = new TextBox();
            textBoxModificar10 = new TextBox();
            labelBuscar10 = new Label();
            labelModificar10 = new Label();
            textBoxUsuarioActual = new TextBox();
            labelUsuarioActual = new Label();
            SuspendLayout();
            // 
            // buttonCrearLista10
            // 
            buttonCrearLista10.Location = new Point(301, 35);
            buttonCrearLista10.Name = "buttonCrearLista10";
            buttonCrearLista10.Size = new Size(96, 23);
            buttonCrearLista10.TabIndex = 0;
            buttonCrearLista10.Text = "Crear lista";
            buttonCrearLista10.UseVisualStyleBackColor = true;
            buttonCrearLista10.Click += buttonCrearLista10_Click;
            // 
            // buttonModificarLista10
            // 
            buttonModificarLista10.Location = new Point(266, 188);
            buttonModificarLista10.Name = "buttonModificarLista10";
            buttonModificarLista10.Size = new Size(96, 23);
            buttonModificarLista10.TabIndex = 1;
            buttonModificarLista10.Text = "Modificar Lista";
            buttonModificarLista10.UseVisualStyleBackColor = true;
            buttonModificarLista10.Click += buttonModificarLista10_Click;
            // 
            // buttonBuscarLista10
            // 
            buttonBuscarLista10.Location = new Point(266, 159);
            buttonBuscarLista10.Name = "buttonBuscarLista10";
            buttonBuscarLista10.Size = new Size(96, 23);
            buttonBuscarLista10.TabIndex = 3;
            buttonBuscarLista10.Text = "Buscar lista";
            buttonBuscarLista10.UseVisualStyleBackColor = true;
            buttonBuscarLista10.Click += buttonBuscarLista10_Click;
            // 
            // labelNombrelista10
            // 
            labelNombrelista10.AutoSize = true;
            labelNombrelista10.Location = new Point(25, 26);
            labelNombrelista10.Name = "labelNombrelista10";
            labelNombrelista10.Size = new Size(106, 15);
            labelNombrelista10.TabIndex = 4;
            labelNombrelista10.Text = "Nombre de la lista:";
            // 
            // labelDescrip10
            // 
            labelDescrip10.AutoSize = true;
            labelDescrip10.Location = new Point(25, 50);
            labelDescrip10.Name = "labelDescrip10";
            labelDescrip10.Size = new Size(112, 15);
            labelDescrip10.TabIndex = 5;
            labelDescrip10.Text = "Descripcion de lista:";
            // 
            // textBoxNombre10
            // 
            textBoxNombre10.Location = new Point(173, 23);
            textBoxNombre10.Margin = new Padding(3, 2, 3, 2);
            textBoxNombre10.Name = "textBoxNombre10";
            textBoxNombre10.Size = new Size(110, 23);
            textBoxNombre10.TabIndex = 6;
            // 
            // textBoxDesc10
            // 
            textBoxDesc10.Location = new Point(173, 50);
            textBoxDesc10.Margin = new Padding(3, 2, 3, 2);
            textBoxDesc10.Name = "textBoxDesc10";
            textBoxDesc10.Size = new Size(110, 23);
            textBoxDesc10.TabIndex = 7;
            // 
            // textBoxBuscar10
            // 
            textBoxBuscar10.Location = new Point(151, 160);
            textBoxBuscar10.Margin = new Padding(3, 2, 3, 2);
            textBoxBuscar10.Name = "textBoxBuscar10";
            textBoxBuscar10.Size = new Size(110, 23);
            textBoxBuscar10.TabIndex = 8;
            // 
            // textBoxModificar10
            // 
            textBoxModificar10.Location = new Point(151, 190);
            textBoxModificar10.Margin = new Padding(3, 2, 3, 2);
            textBoxModificar10.Name = "textBoxModificar10";
            textBoxModificar10.Size = new Size(110, 23);
            textBoxModificar10.TabIndex = 9;
            // 
            // labelBuscar10
            // 
            labelBuscar10.AutoSize = true;
            labelBuscar10.Location = new Point(30, 163);
            labelBuscar10.Name = "labelBuscar10";
            labelBuscar10.Size = new Size(81, 15);
            labelBuscar10.TabIndex = 10;
            labelBuscar10.Text = "Lista a buscar:";
            // 
            // labelModificar10
            // 
            labelModificar10.AutoSize = true;
            labelModificar10.Location = new Point(30, 192);
            labelModificar10.Name = "labelModificar10";
            labelModificar10.Size = new Size(97, 15);
            labelModificar10.TabIndex = 11;
            labelModificar10.Text = "Lista a modificar:";
            // 
            // textBoxUsuarioActual
            // 
            textBoxUsuarioActual.Location = new Point(233, 78);
            textBoxUsuarioActual.Name = "textBoxUsuarioActual";
            textBoxUsuarioActual.Size = new Size(110, 23);
            textBoxUsuarioActual.TabIndex = 12;
            // 
            // labelUsuarioActual
            // 
            labelUsuarioActual.AutoSize = true;
            labelUsuarioActual.Location = new Point(25, 78);
            labelUsuarioActual.Name = "labelUsuarioActual";
            labelUsuarioActual.Size = new Size(197, 15);
            labelUsuarioActual.TabIndex = 13;
            labelUsuarioActual.Text = "Ingrese el usuario quien creo la lista:";
            // 
            // FormListas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(416, 257);
            Controls.Add(labelUsuarioActual);
            Controls.Add(textBoxUsuarioActual);
            Controls.Add(labelModificar10);
            Controls.Add(labelBuscar10);
            Controls.Add(textBoxModificar10);
            Controls.Add(textBoxBuscar10);
            Controls.Add(textBoxDesc10);
            Controls.Add(textBoxNombre10);
            Controls.Add(labelDescrip10);
            Controls.Add(labelNombrelista10);
            Controls.Add(buttonBuscarLista10);
            Controls.Add(buttonModificarLista10);
            Controls.Add(buttonCrearLista10);
            Name = "FormListas";
            Text = "FormListas";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonCrearLista10;
        private Button buttonModificarLista10;
        private Button buttonBuscarLista10;
        private Label labelNombrelista10;
        private Label labelDescrip10;
        private TextBox textBoxNombre10;
        private TextBox textBoxDesc10;
        private TextBox textBoxBuscar10;
        private TextBox textBoxModificar10;
        private Label labelBuscar10;
        private Label labelModificar10;
        private TextBox textBoxUsuarioActual;
        private Label labelUsuarioActual;
    }
}