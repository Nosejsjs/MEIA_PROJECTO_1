﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormBusquedaUsuarios : Form
    {
        public FormBusquedaUsuarios()
        {
            InitializeComponent();
        }
        private void textBoxBuscarUsuario5_TextChanged(object sender, EventArgs e)
        {
            // nosabo jajsa
        }
        private void buttonBuscar5_Click(object sender, EventArgs e)
        {
            string usuarioBuscado = textBoxBuscarUsuario5.Text.Trim();

            if (string.IsNullOrWhiteSpace(usuarioBuscado))
            {
                MostrarMensaje("Por favor ingresa un nombre de usuario.", "Advertencia", MessageBoxIcon.Warning);
                return;
            }

            string rutaArchivoUsuarios = @"C:/MEIA/user.txt";

            if (!File.Exists(rutaArchivoUsuarios))
            {
                MostrarMensaje("No se encontró el archivo de usuarios.", "Error", MessageBoxIcon.Error);
                return;
            }
            var lineas = File.ReadAllLines(rutaArchivoUsuarios);
            var usuarioEncontrado = lineas
                .Select(linea => linea.Split(';'))
                .FirstOrDefault(datos => datos[0].Equals(usuarioBuscado, StringComparison.OrdinalIgnoreCase));

            if (usuarioEncontrado != null)
            {
                MostrarDatosUsuario(usuarioEncontrado);
            }
            else
            {
                MostrarMensaje("Usuario no encontrado.", "Resultado", MessageBoxIcon.Information);
            }
        }
        private void MostrarDatosUsuario(string[] datosUsuario)
        {
            string rol = datosUsuario[4] == "1" ? "Administrador" : "Usuario";
            string estatus = datosUsuario[7] == "1" ? "Activo" : "Inactivo";

            string mensaje = $"Usuario: {datosUsuario[0]}\n" +
                             $"Nombre: {datosUsuario[1]} {datosUsuario[2]}\n" +
                             $"Rol: {rol}\n" +
                             $"Estatus: {estatus}\n" +
                             $"Fecha de Nacimiento: {datosUsuario[5]}\n" +
                             $"Teléfono: {datosUsuario[6]}";

            MostrarMensaje(mensaje, "Usuario Encontrado", MessageBoxIcon.Information);
        }
        private void MostrarMensaje(string mensaje, string titulo, MessageBoxIcon icono)
        {
            MessageBox.Show(mensaje, titulo, MessageBoxButtons.OK, icono);
        }
        private void buttonLimpiar_Click(object sender, EventArgs e)
        {
            textBoxBuscarUsuario5.Clear();
        }
    }
}