﻿namespace MEIA_PROYECTO_1
{
    partial class FormModificarContacto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxNombre9 = new TextBox();
            buttonNombre9 = new Button();
            buttonEstatus9 = new Button();
            SuspendLayout();
            // 
            // textBoxNombre9
            // 
            textBoxNombre9.Location = new Point(30, 26);
            textBoxNombre9.Name = "textBoxNombre9";
            textBoxNombre9.Size = new Size(121, 23);
            textBoxNombre9.TabIndex = 0;
            // 
            // buttonNombre9
            // 
            buttonNombre9.Location = new Point(163, 26);
            buttonNombre9.Name = "buttonNombre9";
            buttonNombre9.Size = new Size(186, 23);
            buttonNombre9.TabIndex = 1;
            buttonNombre9.Text = "Cambiar nombre de contacto";
            buttonNombre9.UseVisualStyleBackColor = true;
            // 
            // buttonEstatus9
            // 
            buttonEstatus9.Location = new Point(71, 55);
            buttonEstatus9.Name = "buttonEstatus9";
            buttonEstatus9.Size = new Size(186, 23);
            buttonEstatus9.TabIndex = 2;
            buttonEstatus9.Text = "Cambiar estatus del contacto";
            buttonEstatus9.UseVisualStyleBackColor = true;
            buttonEstatus9.Click += buttonEstatus9_Click;
            // 
            // FormModificarContacto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(369, 109);
            Controls.Add(buttonEstatus9);
            Controls.Add(buttonNombre9);
            Controls.Add(textBoxNombre9);
            Name = "FormModificarContacto";
            Text = "FormModificarContacto";
            Load += FormModificarContacto_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxNombre9;
        private Button buttonNombre9;
        private Button buttonEstatus9;
    }
}