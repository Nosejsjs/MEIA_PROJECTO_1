﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormRegistro : Form
    {
        public FormRegistro()
        {
            InitializeComponent();
        }

        private void buttonGuardarUsuario3_Click(object sender, EventArgs e)
        {
            var usuarios = GestorArchivos.LeerUsuarios();
            string nuevoUsuario = textBoxUsuario3.Text;

            if (usuarios.ContainsKey(nuevoUsuario))
            {
                MessageBox.Show("El usuario ya existe.");
                return;
            }

            string contraseña = textBoxContraseña3.Text;
            string nivelSeguridad = VerificarNivelSeguridad(contraseña);

            if (nivelSeguridad == "Débil")
            {
                MessageBox.Show("La contraseña es demasiado débil. No se puede registrar el usuario.");
                return;
            }

            var usuario = new Usuario
            {
                NombreUsuario = nuevoUsuario,
                Nombre = textBoxNombre3.Text,
                Apellido = textBoxApellido3.Text,
                Contraseña = ObtenerHashSHA256(contraseña),
                FechaNacimiento = textBoxFechaNacimiento3.Text,
                Telefono = textBoxTelefono3.Text,
                Rol = usuarios.Count == 0 ? 1 : 0,
                Estatus = 1
            };

            usuarios[nuevoUsuario] = usuario;
            GestorArchivos.GuardarUsuarios(usuarios);
            MessageBox.Show("Usuario registrado con éxito.");
            this.Close();
        }

        private string ObtenerHashSHA256(string contraseña)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(contraseña));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private string VerificarNivelSeguridad(string contraseña)
        {
            string criteriosPath = "criteriosContraseñas.txt";
            if (!File.Exists(criteriosPath))
            {
                File.WriteAllText(criteriosPath, "Longitud mínima: 8\nMayúsculas: Sí\nMinúsculas: Sí\nNúmeros: Sí\nCaracteres especiales: Sí");
            }

            bool tieneMayuscula = Regex.IsMatch(contraseña, "[A-Z]");
            bool tieneMinuscula = Regex.IsMatch(contraseña, "[a-z]");
            bool tieneNumero = Regex.IsMatch(contraseña, @"\d");
            bool tieneCaracterEspecial = Regex.IsMatch(contraseña, @"[\W_]");
            bool longitudAdecuada = contraseña.Length >= 8;

            if (longitudAdecuada && tieneMayuscula && tieneMinuscula && tieneNumero && tieneCaracterEspecial)
                return "Fuerte";
            if (longitudAdecuada && (tieneMayuscula || tieneMinuscula) && tieneNumero)
                return "Media";

            return "Débil";
        }
    }
}