﻿namespace MEIA_PROYECTO_1
{
    partial class FormInicioSesion
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxUsuario = new TextBox();
            textBoxContraseña = new TextBox();
            labelUsuario = new Label();
            labelContraseña = new Label();
            buttonIniciarSesion = new Button();
            labelNuevoPregunta = new Label();
            buttonRegistrate = new Button();
            SuspendLayout();
            // 
            // textBoxUsuario
            // 
            textBoxUsuario.Location = new Point(164, 37);
            textBoxUsuario.Name = "textBoxUsuario";
            textBoxUsuario.Size = new Size(100, 23);
            textBoxUsuario.TabIndex = 0;
            // 
            // textBoxContraseña
            // 
            textBoxContraseña.Location = new Point(166, 92);
            textBoxContraseña.Name = "textBoxContraseña";
            textBoxContraseña.Size = new Size(100, 23);
            textBoxContraseña.TabIndex = 1;
            // 
            // labelUsuario
            // 
            labelUsuario.AutoSize = true;
            labelUsuario.Location = new Point(108, 40);
            labelUsuario.Name = "labelUsuario";
            labelUsuario.Size = new Size(50, 15);
            labelUsuario.TabIndex = 2;
            labelUsuario.Text = "Usuario:";
            // 
            // labelContraseña
            // 
            labelContraseña.AutoSize = true;
            labelContraseña.Location = new Point(93, 95);
            labelContraseña.Name = "labelContraseña";
            labelContraseña.Size = new Size(67, 15);
            labelContraseña.TabIndex = 3;
            labelContraseña.Text = "Contraseña";
            // 
            // buttonIniciarSesion
            // 
            buttonIniciarSesion.Location = new Point(128, 148);
            buttonIniciarSesion.Name = "buttonIniciarSesion";
            buttonIniciarSesion.Size = new Size(111, 23);
            buttonIniciarSesion.TabIndex = 4;
            buttonIniciarSesion.Text = "Iniciar Sesion";
            buttonIniciarSesion.UseVisualStyleBackColor = true;
            buttonIniciarSesion.Click += buttonIniciarSesion_Click;
            // 
            // labelNuevoPregunta
            // 
            labelNuevoPregunta.AutoSize = true;
            labelNuevoPregunta.Location = new Point(44, 197);
            labelNuevoPregunta.Name = "labelNuevoPregunta";
            labelNuevoPregunta.Size = new Size(195, 15);
            labelNuevoPregunta.TabIndex = 5;
            labelNuevoPregunta.Text = "Eres nuevo usuario? Registrate aqui:";
            labelNuevoPregunta.Click += label1_Click;
            // 
            // buttonRegistrate
            // 
            buttonRegistrate.Location = new Point(245, 193);
            buttonRegistrate.Name = "buttonRegistrate";
            buttonRegistrate.Size = new Size(75, 23);
            buttonRegistrate.TabIndex = 6;
            buttonRegistrate.Text = "Registrate";
            buttonRegistrate.UseVisualStyleBackColor = true;
            buttonRegistrate.Click += buttonRegistrate_Click;
            // 
            // FormInicioSesion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(359, 221);
            Controls.Add(buttonRegistrate);
            Controls.Add(labelNuevoPregunta);
            Controls.Add(buttonIniciarSesion);
            Controls.Add(labelContraseña);
            Controls.Add(labelUsuario);
            Controls.Add(textBoxContraseña);
            Controls.Add(textBoxUsuario);
            Name = "FormInicioSesion";
            Text = "Inicio de sesion";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxUsuario;
        private TextBox textBoxContraseña;
        private Label labelUsuario;
        private Label labelContraseña;
        private Button buttonIniciarSesion;
        private Label labelNuevoPregunta;
        private Button buttonRegistrate;
    }
}
