﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormModificarDatos : Form
    {
        private Usuario usuario;

        public FormModificarDatos(Usuario usuarioActual)
        {
            InitializeComponent();
            usuario = usuarioActual;
        }

        private void buttonGuardarCambios4_Click(object sender, EventArgs e)
        {
            var usuarios = GestorArchivos.LeerUsuarios();
            usuario.Contraseña = ObtenerHashSHA256(textBoxNuevaContraseña4.Text);
            usuario.FechaNacimiento = textBoxNuevaFechaNacimiento4.Text;
            usuario.Telefono = textBoxNuevoTelefono4.Text;

            usuarios[usuario.NombreUsuario] = usuario;
            GestorArchivos.GuardarUsuarios(usuarios);
            MessageBox.Show("Datos modificados con éxito.");
            this.Close();
        }

        private string ObtenerHashSHA256(string contraseña)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(contraseña));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}