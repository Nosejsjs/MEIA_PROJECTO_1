﻿namespace MEIA_PROYECTO_1
{
    partial class FormBusquedaUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelBuscarUsuario5 = new Label();
            textBoxBuscarUsuario5 = new TextBox();
            buttonBuscar5 = new Button();
            SuspendLayout();
            // 
            // labelBuscarUsuario5
            // 
            labelBuscarUsuario5.AutoSize = true;
            labelBuscarUsuario5.Location = new Point(40, 40);
            labelBuscarUsuario5.Name = "labelBuscarUsuario5";
            labelBuscarUsuario5.Size = new Size(88, 15);
            labelBuscarUsuario5.TabIndex = 0;
            labelBuscarUsuario5.Text = "Buscar Usuario:";
            // 
            // textBoxBuscarUsuario5
            // 
            textBoxBuscarUsuario5.Location = new Point(134, 37);
            textBoxBuscarUsuario5.Name = "textBoxBuscarUsuario5";
            textBoxBuscarUsuario5.Size = new Size(100, 23);
            textBoxBuscarUsuario5.TabIndex = 1;
            textBoxBuscarUsuario5.TextChanged += textBoxBuscarUsuario5_TextChanged;
            // 
            // buttonBuscar5
            // 
            buttonBuscar5.Location = new Point(101, 80);
            buttonBuscar5.Name = "buttonBuscar5";
            buttonBuscar5.Size = new Size(75, 23);
            buttonBuscar5.TabIndex = 2;
            buttonBuscar5.Text = "Buscar";
            buttonBuscar5.UseVisualStyleBackColor = true;
            buttonBuscar5.Click += buttonBuscar5_Click;
            // 
            // FormBusquedaUsuarios
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(287, 120);
            Controls.Add(buttonBuscar5);
            Controls.Add(textBoxBuscarUsuario5);
            Controls.Add(labelBuscarUsuario5);
            Name = "FormBusquedaUsuarios";
            Text = "Busqueda de Usuarios";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelBuscarUsuario5;
        private TextBox textBoxBuscarUsuario5;
        private Button buttonBuscar5;
    }
}