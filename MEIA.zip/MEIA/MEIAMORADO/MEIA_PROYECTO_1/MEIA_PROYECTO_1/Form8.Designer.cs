﻿namespace MEIA_PROYECTO_1
{
    partial class FormContacto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelUsuarioTransaccion8 = new Label();
            buttonBuscarUsuario8 = new Button();
            comboBoxBusqueda8 = new ComboBox();
            textBoxBusquedaUsuario8 = new TextBox();
            buttonAgregarContacto = new Button();
            buttonEliminarContacto8 = new Button();
            buttonModificarContacto = new Button();
            textBoxBusquedaContacto8 = new TextBox();
            buttonBuscarContacto8 = new Button();
            labelUsuarioUser8 = new Label();
            labelShowUsuarioUser8 = new Label();
            labelNombreUser8 = new Label();
            labelShowNombreUser8 = new Label();
            labelApellidoUser8 = new Label();
            labelShowApellidoUser8 = new Label();
            labelUsuarioContacto8 = new Label();
            labelNombreContacto8 = new Label();
            labelShowUsuarioContacto8 = new Label();
            labelShowNombreContacto8 = new Label();
            labelFechaContacto8 = new Label();
            labelShowFechaContacto8 = new Label();
            labelUsuarioTrans8 = new Label();
            labelShowUsuarioTrans8 = new Label();
            labelEstatusContacto8 = new Label();
            labelShowEstatusContacto8 = new Label();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            labelUtrans = new Label();
            textBoxUsuarioTransaccion = new TextBox();
            SuspendLayout();
            // 
            // labelUsuarioTransaccion8
            // 
            labelUsuarioTransaccion8.AutoSize = true;
            labelUsuarioTransaccion8.Location = new Point(272, 22);
            labelUsuarioTransaccion8.Name = "labelUsuarioTransaccion8";
            labelUsuarioTransaccion8.Size = new Size(0, 15);
            labelUsuarioTransaccion8.TabIndex = 5;
            // 
            // buttonBuscarUsuario8
            // 
            buttonBuscarUsuario8.Location = new Point(278, 12);
            buttonBuscarUsuario8.Name = "buttonBuscarUsuario8";
            buttonBuscarUsuario8.Size = new Size(107, 23);
            buttonBuscarUsuario8.TabIndex = 8;
            buttonBuscarUsuario8.Text = "Buscar Usuario";
            buttonBuscarUsuario8.UseVisualStyleBackColor = true;
            buttonBuscarUsuario8.Click += buttonBuscarUsuario8_Click;
            // 
            // comboBoxBusqueda8
            // 
            comboBoxBusqueda8.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxBusqueda8.FormattingEnabled = true;
            comboBoxBusqueda8.Items.AddRange(new object[] { "Usuario", "Nombre", "Apellidos" });
            comboBoxBusqueda8.Location = new Point(151, 12);
            comboBoxBusqueda8.Name = "comboBoxBusqueda8";
            comboBoxBusqueda8.Size = new Size(121, 23);
            comboBoxBusqueda8.TabIndex = 7;
            // 
            // textBoxBusquedaUsuario8
            // 
            textBoxBusquedaUsuario8.Location = new Point(12, 12);
            textBoxBusquedaUsuario8.Name = "textBoxBusquedaUsuario8";
            textBoxBusquedaUsuario8.Size = new Size(131, 23);
            textBoxBusquedaUsuario8.TabIndex = 6;
            // 
            // buttonAgregarContacto
            // 
            buttonAgregarContacto.Location = new Point(12, 52);
            buttonAgregarContacto.Name = "buttonAgregarContacto";
            buttonAgregarContacto.Size = new Size(131, 39);
            buttonAgregarContacto.TabIndex = 9;
            buttonAgregarContacto.Text = "Agregar a contactos";
            buttonAgregarContacto.UseVisualStyleBackColor = true;
            buttonAgregarContacto.Click += buttonAgregarContacto_Click;
            // 
            // buttonEliminarContacto8
            // 
            buttonEliminarContacto8.Location = new Point(12, 222);
            buttonEliminarContacto8.Name = "buttonEliminarContacto8";
            buttonEliminarContacto8.Size = new Size(131, 23);
            buttonEliminarContacto8.TabIndex = 10;
            buttonEliminarContacto8.Text = "Eliminar contacto";
            buttonEliminarContacto8.UseVisualStyleBackColor = true;
            buttonEliminarContacto8.Click += buttonEliminarContacto8_Click;
            // 
            // buttonModificarContacto
            // 
            buttonModificarContacto.Location = new Point(12, 251);
            buttonModificarContacto.Name = "buttonModificarContacto";
            buttonModificarContacto.Size = new Size(131, 23);
            buttonModificarContacto.TabIndex = 11;
            buttonModificarContacto.Text = "Modificar contacto";
            buttonModificarContacto.UseVisualStyleBackColor = true;
            buttonModificarContacto.Click += buttonModificarContacto_Click_1;
            // 
            // textBoxBusquedaContacto8
            // 
            textBoxBusquedaContacto8.Location = new Point(12, 193);
            textBoxBusquedaContacto8.Name = "textBoxBusquedaContacto8";
            textBoxBusquedaContacto8.Size = new Size(131, 23);
            textBoxBusquedaContacto8.TabIndex = 12;
            // 
            // buttonBuscarContacto8
            // 
            buttonBuscarContacto8.Location = new Point(149, 193);
            buttonBuscarContacto8.Name = "buttonBuscarContacto8";
            buttonBuscarContacto8.Size = new Size(141, 23);
            buttonBuscarContacto8.TabIndex = 13;
            buttonBuscarContacto8.Text = "Buscar en contactos";
            buttonBuscarContacto8.UseVisualStyleBackColor = true;
            buttonBuscarContacto8.Click += buttonBuscarContacto8_Click;
            // 
            // labelUsuarioUser8
            // 
            labelUsuarioUser8.AutoSize = true;
            labelUsuarioUser8.Location = new Point(161, 57);
            labelUsuarioUser8.Name = "labelUsuarioUser8";
            labelUsuarioUser8.Size = new Size(50, 15);
            labelUsuarioUser8.TabIndex = 14;
            labelUsuarioUser8.Text = "Usuario:";
            // 
            // labelShowUsuarioUser8
            // 
            labelShowUsuarioUser8.AutoSize = true;
            labelShowUsuarioUser8.Location = new Point(217, 56);
            labelShowUsuarioUser8.Name = "labelShowUsuarioUser8";
            labelShowUsuarioUser8.Size = new Size(16, 15);
            labelShowUsuarioUser8.TabIndex = 15;
            labelShowUsuarioUser8.Text = "...";
            // 
            // labelNombreUser8
            // 
            labelNombreUser8.AutoSize = true;
            labelNombreUser8.Location = new Point(161, 72);
            labelNombreUser8.Name = "labelNombreUser8";
            labelNombreUser8.Size = new Size(54, 15);
            labelNombreUser8.TabIndex = 16;
            labelNombreUser8.Text = "Nombre:";
            // 
            // labelShowNombreUser8
            // 
            labelShowNombreUser8.AutoSize = true;
            labelShowNombreUser8.Location = new Point(217, 71);
            labelShowNombreUser8.Name = "labelShowNombreUser8";
            labelShowNombreUser8.Size = new Size(16, 15);
            labelShowNombreUser8.TabIndex = 17;
            labelShowNombreUser8.Text = "...";
            // 
            // labelApellidoUser8
            // 
            labelApellidoUser8.AutoSize = true;
            labelApellidoUser8.Location = new Point(161, 87);
            labelApellidoUser8.Name = "labelApellidoUser8";
            labelApellidoUser8.Size = new Size(54, 15);
            labelApellidoUser8.TabIndex = 18;
            labelApellidoUser8.Text = "Apellido:";
            // 
            // labelShowApellidoUser8
            // 
            labelShowApellidoUser8.AutoSize = true;
            labelShowApellidoUser8.Location = new Point(217, 86);
            labelShowApellidoUser8.Name = "labelShowApellidoUser8";
            labelShowApellidoUser8.Size = new Size(16, 15);
            labelShowApellidoUser8.TabIndex = 19;
            labelShowApellidoUser8.Text = "...";
            // 
            // labelUsuarioContacto8
            // 
            labelUsuarioContacto8.AutoSize = true;
            labelUsuarioContacto8.Location = new Point(159, 228);
            labelUsuarioContacto8.Name = "labelUsuarioContacto8";
            labelUsuarioContacto8.Size = new Size(50, 15);
            labelUsuarioContacto8.TabIndex = 20;
            labelUsuarioContacto8.Text = "Usuario:";
            // 
            // labelNombreContacto8
            // 
            labelNombreContacto8.AutoSize = true;
            labelNombreContacto8.Location = new Point(159, 247);
            labelNombreContacto8.Name = "labelNombreContacto8";
            labelNombreContacto8.Size = new Size(54, 15);
            labelNombreContacto8.TabIndex = 21;
            labelNombreContacto8.Text = "Nombre:";
            // 
            // labelShowUsuarioContacto8
            // 
            labelShowUsuarioContacto8.AutoSize = true;
            labelShowUsuarioContacto8.Location = new Point(217, 228);
            labelShowUsuarioContacto8.Name = "labelShowUsuarioContacto8";
            labelShowUsuarioContacto8.Size = new Size(16, 15);
            labelShowUsuarioContacto8.TabIndex = 22;
            labelShowUsuarioContacto8.Text = "...";
            // 
            // labelShowNombreContacto8
            // 
            labelShowNombreContacto8.AutoSize = true;
            labelShowNombreContacto8.Location = new Point(217, 247);
            labelShowNombreContacto8.Name = "labelShowNombreContacto8";
            labelShowNombreContacto8.Size = new Size(16, 15);
            labelShowNombreContacto8.TabIndex = 23;
            labelShowNombreContacto8.Text = "...";
            // 
            // labelFechaContacto8
            // 
            labelFechaContacto8.AutoSize = true;
            labelFechaContacto8.Location = new Point(159, 267);
            labelFechaContacto8.Name = "labelFechaContacto8";
            labelFechaContacto8.Size = new Size(41, 15);
            labelFechaContacto8.TabIndex = 24;
            labelFechaContacto8.Text = "Fecha:";
            // 
            // labelShowFechaContacto8
            // 
            labelShowFechaContacto8.AutoSize = true;
            labelShowFechaContacto8.Location = new Point(217, 267);
            labelShowFechaContacto8.Name = "labelShowFechaContacto8";
            labelShowFechaContacto8.Size = new Size(16, 15);
            labelShowFechaContacto8.TabIndex = 25;
            labelShowFechaContacto8.Text = "...";
            // 
            // labelUsuarioTrans8
            // 
            labelUsuarioTrans8.AutoSize = true;
            labelUsuarioTrans8.Location = new Point(159, 285);
            labelUsuarioTrans8.Name = "labelUsuarioTrans8";
            labelUsuarioTrans8.Size = new Size(130, 15);
            labelUsuarioTrans8.TabIndex = 26;
            labelUsuarioTrans8.Text = "Usuario de transacción:";
            // 
            // labelShowUsuarioTrans8
            // 
            labelShowUsuarioTrans8.AutoSize = true;
            labelShowUsuarioTrans8.Location = new Point(295, 285);
            labelShowUsuarioTrans8.Name = "labelShowUsuarioTrans8";
            labelShowUsuarioTrans8.Size = new Size(16, 15);
            labelShowUsuarioTrans8.TabIndex = 27;
            labelShowUsuarioTrans8.Text = "...";
            // 
            // labelEstatusContacto8
            // 
            labelEstatusContacto8.AutoSize = true;
            labelEstatusContacto8.Location = new Point(159, 301);
            labelEstatusContacto8.Name = "labelEstatusContacto8";
            labelEstatusContacto8.Size = new Size(47, 15);
            labelEstatusContacto8.TabIndex = 28;
            labelEstatusContacto8.Text = "Estatus:";
            // 
            // labelShowEstatusContacto8
            // 
            labelShowEstatusContacto8.AutoSize = true;
            labelShowEstatusContacto8.Location = new Point(217, 301);
            labelShowEstatusContacto8.Name = "labelShowEstatusContacto8";
            labelShowEstatusContacto8.Size = new Size(16, 15);
            labelShowEstatusContacto8.TabIndex = 29;
            labelShowEstatusContacto8.Text = "...";
            // 
            // labelUtrans
            // 
            labelUtrans.AutoSize = true;
            labelUtrans.Location = new Point(14, 121);
            labelUtrans.Name = "labelUtrans";
            labelUtrans.Size = new Size(182, 15);
            labelUtrans.TabIndex = 30;
            labelUtrans.Text = "Ingrese el usuario de transaccion:";
            // 
            // textBoxUsuarioTransaccion
            // 
            textBoxUsuarioTransaccion.Location = new Point(203, 114);
            textBoxUsuarioTransaccion.Name = "textBoxUsuarioTransaccion";
            textBoxUsuarioTransaccion.Size = new Size(100, 23);
            textBoxUsuarioTransaccion.TabIndex = 31;
            textBoxUsuarioTransaccion.TextChanged += textBoxUsuarioTransaccion_TextChanged;
            // 
            // FormContacto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(391, 348);
            Controls.Add(textBoxUsuarioTransaccion);
            Controls.Add(labelUtrans);
            Controls.Add(labelShowEstatusContacto8);
            Controls.Add(labelEstatusContacto8);
            Controls.Add(labelShowUsuarioTrans8);
            Controls.Add(labelUsuarioTrans8);
            Controls.Add(labelShowFechaContacto8);
            Controls.Add(labelFechaContacto8);
            Controls.Add(labelShowNombreContacto8);
            Controls.Add(labelShowUsuarioContacto8);
            Controls.Add(labelNombreContacto8);
            Controls.Add(labelUsuarioContacto8);
            Controls.Add(labelShowApellidoUser8);
            Controls.Add(labelApellidoUser8);
            Controls.Add(labelShowNombreUser8);
            Controls.Add(labelNombreUser8);
            Controls.Add(labelShowUsuarioUser8);
            Controls.Add(labelUsuarioUser8);
            Controls.Add(buttonBuscarContacto8);
            Controls.Add(textBoxBusquedaContacto8);
            Controls.Add(buttonModificarContacto);
            Controls.Add(buttonEliminarContacto8);
            Controls.Add(buttonAgregarContacto);
            Controls.Add(buttonBuscarUsuario8);
            Controls.Add(comboBoxBusqueda8);
            Controls.Add(textBoxBusquedaUsuario8);
            Controls.Add(labelUsuarioTransaccion8);
            Name = "FormContacto";
            Text = "FormContacto";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label labelUsuarioTransaccion8;
        private ListBox listBox1;
        private Button buttonBuscarUsuario8;
        private ComboBox comboBoxBusqueda8;
        private TextBox textBoxBusquedaUsuario8;
        private Button buttonAgregarContacto;
        private Button buttonEliminarContacto8;
        private Button buttonModificarContacto;
        private TextBox textBoxBusquedaContacto8;
        private Button buttonBuscarContacto8;
        private Label labelUsuarioUser8;
        private Label labelShowUsuarioUser8;
        private Label labelNombreUser8;
        private Label labelShowNombreUser8;
        private Label labelApellidoUser8;
        private Label labelShowApellidoUser8;
        private Label labelUsuarioContacto8;
        private Label labelNombreContacto8;
        private Label labelShowUsuarioContacto8;
        private Label labelShowNombreContacto8;
        private Label labelFechaContacto8;
        private Label labelShowFechaContacto8;
        private Label labelUsuarioTrans8;
        private Label labelShowUsuarioTrans8;
        private Label labelEstatusContacto8;
        private Label labelShowEstatusContacto8;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Label labelUtrans;
        private TextBox textBoxUsuarioTransaccion;
    }
}