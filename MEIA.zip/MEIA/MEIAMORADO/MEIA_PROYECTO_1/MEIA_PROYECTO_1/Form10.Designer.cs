﻿namespace MEIA_PROYECTO_1
{
    partial class FormMantenimientoListaUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonAgregar10 = new Button();
            buttonBuscar10 = new Button();
            buttonModificar10 = new Button();
            buttonEliminar10 = new Button();
            textBoxAgregar10 = new TextBox();
            textBoxBuscar10 = new TextBox();
            textBoxModificar10 = new TextBox();
            textBoxEliminar10 = new TextBox();
            SuspendLayout();
            // 
            // buttonAgregar10
            // 
            buttonAgregar10.Location = new Point(161, 35);
            buttonAgregar10.Name = "buttonAgregar10";
            buttonAgregar10.Size = new Size(75, 23);
            buttonAgregar10.TabIndex = 0;
            buttonAgregar10.Text = "Agregar";
            buttonAgregar10.UseVisualStyleBackColor = true;
            // 
            // buttonBuscar10
            // 
            buttonBuscar10.Location = new Point(161, 64);
            buttonBuscar10.Name = "buttonBuscar10";
            buttonBuscar10.Size = new Size(75, 23);
            buttonBuscar10.TabIndex = 1;
            buttonBuscar10.Text = "Buscar";
            buttonBuscar10.UseVisualStyleBackColor = true;
            // 
            // buttonModificar10
            // 
            buttonModificar10.Location = new Point(161, 93);
            buttonModificar10.Name = "buttonModificar10";
            buttonModificar10.Size = new Size(75, 23);
            buttonModificar10.TabIndex = 2;
            buttonModificar10.Text = "Modificar";
            buttonModificar10.UseVisualStyleBackColor = true;
            // 
            // buttonEliminar10
            // 
            buttonEliminar10.Location = new Point(161, 122);
            buttonEliminar10.Name = "buttonEliminar10";
            buttonEliminar10.Size = new Size(75, 23);
            buttonEliminar10.TabIndex = 3;
            buttonEliminar10.Text = "Eliminar";
            buttonEliminar10.UseVisualStyleBackColor = true;
            // 
            // textBoxAgregar10
            // 
            textBoxAgregar10.Location = new Point(55, 36);
            textBoxAgregar10.Name = "textBoxAgregar10";
            textBoxAgregar10.Size = new Size(100, 23);
            textBoxAgregar10.TabIndex = 4;
            // 
            // textBoxBuscar10
            // 
            textBoxBuscar10.Location = new Point(55, 65);
            textBoxBuscar10.Name = "textBoxBuscar10";
            textBoxBuscar10.Size = new Size(100, 23);
            textBoxBuscar10.TabIndex = 5;
            // 
            // textBoxModificar10
            // 
            textBoxModificar10.Location = new Point(55, 94);
            textBoxModificar10.Name = "textBoxModificar10";
            textBoxModificar10.Size = new Size(100, 23);
            textBoxModificar10.TabIndex = 6;
            // 
            // textBoxEliminar10
            // 
            textBoxEliminar10.Location = new Point(55, 123);
            textBoxEliminar10.Name = "textBoxEliminar10";
            textBoxEliminar10.Size = new Size(100, 23);
            textBoxEliminar10.TabIndex = 7;
            // 
            // FormMantenimientoListaUsuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(276, 167);
            Controls.Add(textBoxEliminar10);
            Controls.Add(textBoxModificar10);
            Controls.Add(textBoxBuscar10);
            Controls.Add(textBoxAgregar10);
            Controls.Add(buttonEliminar10);
            Controls.Add(buttonModificar10);
            Controls.Add(buttonBuscar10);
            Controls.Add(buttonAgregar10);
            Name = "FormMantenimientoListaUsuario";
            Text = "FormMantenimientoListaUsuario";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonAgregar10;
        private Button buttonBuscar10;
        private Button buttonModificar10;
        private Button buttonEliminar10;
        private TextBox textBoxAgregar10;
        private TextBox textBoxBuscar10;
        private TextBox textBoxModificar10;
        private TextBox textBoxEliminar10;
    }
}