﻿using System;
using System.Collections.Generic;
using System.IO;

public static class GestorContactos
{
    private static string RUTA_ARCHIVO = "C:/MEIA/contactos.txt";

    public class Contacto
    {
        public string Usuario { get; set; }
        public string ContactoUsuario { get; set; }
        public DateTime FechaTransaccion { get; set; }
        public string UsuarioTransaccion { get; set; }
        public bool Estatus { get; set; } // true = Activo, false = Inactivo
    }

    public static void AgregarContacto(string usuario, string contactoUsuario, string usuarioTransaccion)
    {
        string nuevoRegistro = $"{usuario};{contactoUsuario};{DateTime.Now};{usuarioTransaccion};1"; 

        using (StreamWriter sw = File.AppendText(RUTA_ARCHIVO))
        {
            sw.WriteLine(nuevoRegistro);
        }
    }

    public static List<Contacto> LeerContactos()
    {
        var contactos = new List<Contacto>();
        if (File.Exists(RUTA_ARCHIVO))
        {
            foreach (var linea in File.ReadAllLines(RUTA_ARCHIVO))
            {
                var partes = linea.Split(';');
                if (partes.Length == 5)
                {
                    contactos.Add(new Contacto
                    {
                        Usuario = partes[0],
                        ContactoUsuario = partes[1],
                        FechaTransaccion = DateTime.Parse(partes[2]),
                        UsuarioTransaccion = partes[3],
                        Estatus = partes[4] == "1" 
                    });
                }
            }
        }
        return contactos;
    }

    public static void EliminarContacto(string usuario, string contactoUsuario)
    {
        var lineas = File.ReadAllLines(RUTA_ARCHIVO);
        for (int i = 0; i < lineas.Length; i++)
        {
            var partes = lineas[i].Split(';');
            if (partes[0] == usuario && partes[1] == contactoUsuario)
            {
                partes[4] = "0"; 
                lineas[i] = string.Join(';', partes);
                break;
            }
        }
        File.WriteAllLines(RUTA_ARCHIVO, lineas);
    }

    public static void EditarContacto(string usuario, string contactoUsuario, string nuevoContactoUsuario, string usuarioTransaccion)
    {
        var lineas = File.ReadAllLines(RUTA_ARCHIVO);
        for (int i = 0; i < lineas.Length; i++)
        {
            var partes = lineas[i].Split(';');
            if (partes[0] == usuario && partes[1] == contactoUsuario)
            {
                partes[1] = nuevoContactoUsuario;
                partes[2] = DateTime.Now.ToString(); 
                partes[3] = usuarioTransaccion; 
                lineas[i] = string.Join(';', partes);
                break;
            }
        }
        File.WriteAllLines(RUTA_ARCHIVO, lineas);
    }
}
