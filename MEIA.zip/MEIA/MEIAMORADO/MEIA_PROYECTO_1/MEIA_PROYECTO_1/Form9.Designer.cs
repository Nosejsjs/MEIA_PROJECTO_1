﻿namespace MEIA_PROYECTO_1
{
    partial class FormListaDifusion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonAgregar9 = new Button();
            buttonBuscar9 = new Button();
            buttonModificar9 = new Button();
            buttonEliminar9 = new Button();
            textBoxAgregar9 = new TextBox();
            textBoxBuscar9 = new TextBox();
            textBoxModificar9 = new TextBox();
            textBoxEliminar9 = new TextBox();
            SuspendLayout();
            // 
            // buttonAgregar9
            // 
            buttonAgregar9.Location = new Point(177, 40);
            buttonAgregar9.Name = "buttonAgregar9";
            buttonAgregar9.Size = new Size(75, 23);
            buttonAgregar9.TabIndex = 0;
            buttonAgregar9.Text = "agregar";
            buttonAgregar9.UseVisualStyleBackColor = true;
            // 
            // buttonBuscar9
            // 
            buttonBuscar9.Location = new Point(177, 69);
            buttonBuscar9.Name = "buttonBuscar9";
            buttonBuscar9.Size = new Size(75, 23);
            buttonBuscar9.TabIndex = 1;
            buttonBuscar9.Text = "Buscar";
            buttonBuscar9.UseVisualStyleBackColor = true;
            // 
            // buttonModificar9
            // 
            buttonModificar9.Location = new Point(177, 98);
            buttonModificar9.Name = "buttonModificar9";
            buttonModificar9.Size = new Size(75, 23);
            buttonModificar9.TabIndex = 2;
            buttonModificar9.Text = "modificar";
            buttonModificar9.UseVisualStyleBackColor = true;
            // 
            // buttonEliminar9
            // 
            buttonEliminar9.Location = new Point(177, 127);
            buttonEliminar9.Name = "buttonEliminar9";
            buttonEliminar9.Size = new Size(75, 23);
            buttonEliminar9.TabIndex = 3;
            buttonEliminar9.Text = "Eliminar";
            buttonEliminar9.UseVisualStyleBackColor = true;
            // 
            // textBoxAgregar9
            // 
            textBoxAgregar9.Location = new Point(61, 40);
            textBoxAgregar9.Name = "textBoxAgregar9";
            textBoxAgregar9.Size = new Size(100, 23);
            textBoxAgregar9.TabIndex = 4;
            // 
            // textBoxBuscar9
            // 
            textBoxBuscar9.Location = new Point(61, 69);
            textBoxBuscar9.Name = "textBoxBuscar9";
            textBoxBuscar9.Size = new Size(100, 23);
            textBoxBuscar9.TabIndex = 5;
            // 
            // textBoxModificar9
            // 
            textBoxModificar9.Location = new Point(61, 98);
            textBoxModificar9.Name = "textBoxModificar9";
            textBoxModificar9.Size = new Size(100, 23);
            textBoxModificar9.TabIndex = 6;
            // 
            // textBoxEliminar9
            // 
            textBoxEliminar9.Location = new Point(61, 127);
            textBoxEliminar9.Name = "textBoxEliminar9";
            textBoxEliminar9.Size = new Size(100, 23);
            textBoxEliminar9.TabIndex = 7;
            // 
            // FormListaDifusion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(317, 191);
            Controls.Add(textBoxEliminar9);
            Controls.Add(textBoxModificar9);
            Controls.Add(textBoxBuscar9);
            Controls.Add(textBoxAgregar9);
            Controls.Add(buttonEliminar9);
            Controls.Add(buttonModificar9);
            Controls.Add(buttonBuscar9);
            Controls.Add(buttonAgregar9);
            Name = "FormListaDifusion";
            Text = "FormListaDifusion";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonAgregar9;
        private Button buttonBuscar9;
        private Button buttonModificar9;
        private Button buttonEliminar9;
        private TextBox textBoxAgregar9;
        private TextBox textBoxBuscar9;
        private TextBox textBoxModificar9;
        private TextBox textBoxEliminar9;
    }
}