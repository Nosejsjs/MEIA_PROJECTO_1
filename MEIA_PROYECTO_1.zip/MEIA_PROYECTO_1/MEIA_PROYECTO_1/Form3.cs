﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormRegistro : Form
    {
        public FormRegistro()
        {
            InitializeComponent();
        }

        private void buttonGuardarUsuario3_Click(object sender, EventArgs e)
        {
            var usuarios = GestorArchivos.LeerUsuarios();
            string nuevoUsuario = textBoxUsuario3.Text;

            if (usuarios.ContainsKey(nuevoUsuario))
            {
                MessageBox.Show("El usuario ya existe.");
                return;
            }

            var usuario = new Usuario
            {
                NombreUsuario = nuevoUsuario,
                Nombre = textBoxNombre3.Text,
                Apellido = textBoxApellido3.Text,
                Contraseña = ObtenerHashSHA256(textBoxContraseña3.Text),
                FechaNacimiento = textBoxFechaNacimiento3.Text,
                Telefono = textBoxTelefono3.Text,
                Rol = usuarios.Count == 0 ? 1 : 0,
                Estatus = 1
            };

            usuarios[nuevoUsuario] = usuario;
            GestorArchivos.GuardarUsuarios(usuarios);
            MessageBox.Show("Usuario registrado con éxito.");
            this.Close();
        }

        private string ObtenerHashSHA256(string contraseña)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(contraseña));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
