﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormDarBaja : Form
    {
        private string usuarioActual;

        public FormDarBaja(string usuarioLogueado)
        {
            InitializeComponent();
            usuarioActual = usuarioLogueado;
        }
        private void buttonOk6_Click(object sender, EventArgs e)
        {
            string usuarioDarBaja = textBoxUsuarioDarBaja6.Text.Trim();

            if (string.IsNullOrWhiteSpace(usuarioDarBaja))
            {
                MostrarMensaje("Por favor, ingresa un nombre de usuario.", "Advertencia", MessageBoxIcon.Warning);
                return;
            }

            if (usuarioDarBaja.Equals(usuarioActual, StringComparison.OrdinalIgnoreCase))
            {
                MostrarMensaje("No puedes darte de baja a ti mismo.", "Advertencia", MessageBoxIcon.Warning);
                return;
            }

            string rutaArchivoUsuarios = @"C:/MEIA/user.txt";

            if (!File.Exists(rutaArchivoUsuarios))
            {
                MostrarMensaje("No se encontró el archivo de usuarios.", "Error", MessageBoxIcon.Error);
                return;
            }
            var lineas = File.ReadAllLines(rutaArchivoUsuarios);
            var usuarioEncontrado = lineas
                .Select(linea => linea.Split(';'))
                .FirstOrDefault(datos => datos[0].Equals(usuarioDarBaja, StringComparison.OrdinalIgnoreCase));

            if (usuarioEncontrado != null)
            {
                DialogResult resultado = MessageBox.Show(
                    $"¿Estás seguro de que deseas dar de baja al usuario {usuarioDarBaja}?",
                    "Confirmación",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    DarDeBajaUsuario(usuarioDarBaja);
                }
            }
            else
            {
                MostrarMensaje("Usuario no encontrado.", "Resultado", MessageBoxIcon.Information);
            }
        }
        private void DarDeBajaUsuario(string nombreUsuario)
        {
            string rutaArchivoUsuarios = @"C:/MEIA/user.txt";
            string[] lineas = File.ReadAllLines(rutaArchivoUsuarios);
            bool usuarioEncontrado = false;

            for (int i = 0; i < lineas.Length; i++)
            {
                var datos = lineas[i].Split(';');
                if (datos[0].Equals(nombreUsuario, StringComparison.OrdinalIgnoreCase))
                {
                    datos[7] = "0";
                    lineas[i] = string.Join(';', datos);
                    usuarioEncontrado = true;
                    break;
                }
            }

            if (usuarioEncontrado)
            {
                File.WriteAllLines(rutaArchivoUsuarios, lineas);
                MostrarMensaje("El usuario ha sido dado de baja correctamente.", "Éxito", MessageBoxIcon.Information);
            }
            else
            {
                MostrarMensaje("No se pudo dar de baja al usuario.", "Error", MessageBoxIcon.Error);
            }
        }
        private void MostrarMensaje(string mensaje, string titulo, MessageBoxIcon icono)
        {
            MessageBox.Show(mensaje, titulo, MessageBoxButtons.OK, icono);
        }
        private void buttonCancelar6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
