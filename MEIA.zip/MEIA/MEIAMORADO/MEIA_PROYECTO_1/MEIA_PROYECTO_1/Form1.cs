using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Text;

namespace MEIA_PROYECTO_1
{
    public partial class FormInicioSesion : Form
    {
        private Dictionary<string, Usuario> usuarios;

        public FormInicioSesion()
        {
            InitializeComponent();
            usuarios = GestorArchivos.LeerUsuarios();
            textBoxContrase�a.UseSystemPasswordChar = true;
        }

        private void buttonIniciarSesion_Click(object sender, EventArgs e)
        {
            string usuario = textBoxUsuario.Text;
            string contrase�a = textBoxContrase�a.Text;
            string contrase�aHash = HashPassword(contrase�a);

            if (usuarios.ContainsKey(usuario) &&
                usuarios[usuario].Contrase�a == contrase�aHash &&
                usuarios[usuario].Estatus == 1)
            {
                Usuario usuarioLogueado = usuarios[usuario];
                if (usuarioLogueado.Rol == 1)
                {
                    var formAdmin = new FormMenuAdmin(usuarioLogueado);
                    formAdmin.Show();
                }
                else
                {
                    var formMenuUsuarios = new FormMenuUsuarios(usuarioLogueado);
                    formMenuUsuarios.Show();
                }
                this.Hide();
            }
            else
            {
                MessageBox.Show("Credenciales incorrectas o usuario inactivo.");
            }
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));

                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonRegistrate_Click(object sender, EventArgs e)
        {
            var formRegistro = new FormRegistro();
            formRegistro.Show();
        }
    }
}

