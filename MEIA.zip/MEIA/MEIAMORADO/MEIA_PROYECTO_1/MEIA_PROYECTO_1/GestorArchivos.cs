﻿using System;
using System.Collections.Generic;
using System.IO;

namespace MEIA_PROYECTO_1
{
    public static class GestorArchivos
    {
        private static string BASE_DIR = "C:/MEIA";
        private static string USER_FILE = Path.Combine(BASE_DIR, "user.txt");

        public static Dictionary<string, Usuario> LeerUsuarios()
        {
            var usuarios = new Dictionary<string, Usuario>();
            if (File.Exists(USER_FILE))
            {
                foreach (var linea in File.ReadAllLines(USER_FILE))
                {
                    var partes = linea.Split(';');
                    if (partes.Length >= 8)
                    {
                        usuarios[partes[0]] = new Usuario
                        {
                            NombreUsuario = partes[0],
                            Nombre = partes[1],
                            Apellido = partes[2],
                            Contraseña = partes[3],
                            Rol = int.Parse(partes[4]),
                            FechaNacimiento = partes[5],
                            Telefono = partes[6],
                            Estatus = int.Parse(partes[7])
                        };
                    }
                }
            }
            return usuarios;
        }

        public static void GuardarUsuarios(Dictionary<string, Usuario> usuarios)
        {
            using (var writer = new StreamWriter(USER_FILE, false))
            {
                foreach (var usuario in usuarios.Values)
                {
                    writer.WriteLine($"{usuario.NombreUsuario};{usuario.Nombre};{usuario.Apellido};" +
                                     $"{usuario.Contraseña};{usuario.Rol};{usuario.FechaNacimiento};" +
                                     $"{usuario.Telefono};{usuario.Estatus}");
                }
            }
        }
    }
}