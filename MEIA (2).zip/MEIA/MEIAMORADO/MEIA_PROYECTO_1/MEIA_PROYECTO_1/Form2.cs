﻿using System;
using System.IO;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormMenuAdmin : Form
    {
        private Usuario usuario;

        public FormMenuAdmin(Usuario usuarioLogueado)
        {
            InitializeComponent();
            usuario = usuarioLogueado;
            labelAdminName.Text = usuario.Nombre;
            labelNombreNombre2.Text = usuario.Nombre;
            labelApellidoApellido2.Text = usuario.Apellido;
            labelAdminRol.Text = usuario.Rol == 1 ? "Administrador" : "Usuario";
            labelTelefonoAdmin.Text = usuario.Telefono;
            labelEstatusEstatus.Text = usuario.Estatus == 1 ? "Activo" : "Inactivo";
            labelFecha2.Text = usuario.FechaNacimiento;
        }

        private void buttonNuevoUsuario_Click(object sender, EventArgs e)
        {
            var formRegistro = new FormRegistro();
            formRegistro.Show();
        }

        private void buttonModificarDatos_Click(object sender, EventArgs e)
        {
            var formModificar = new FormModificarDatos(usuario);
            formModificar.Show();
        }

        private void buttonCerrarSesion_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void buttonBusquedaUsuarios_Click(object sender, EventArgs e)
        {
            var formBusquedaUsuarios = new FormBusquedaUsuarios();
            formBusquedaUsuarios.Show();
        }

        private void buttonDarBaja_Click(object sender, EventArgs e)
        {
            string usuarioLogueado = "NombreUsuario";
            var formDarBaja = new FormDarBaja(usuarioLogueado);
            formDarBaja.Show();
        }

        private void buttonRespaldo_Click(object sender, EventArgs e)
        {
            string rutaArchivoUsuarios = @"C:/MEIA/user.txt";
            string rutaRespaldo = @"C:/MEIA/bitacora_backup.txt";

            try
            {
                if (File.Exists(rutaArchivoUsuarios))
                {
                    File.Copy(rutaArchivoUsuarios, rutaRespaldo, true);
                    MessageBox.Show("Copia de seguridad realizada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("El archivo de usuarios no existe.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al realizar la copia de seguridad: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void labelNombreNombre2_Click(object sender, EventArgs e)
        {

        }

        private void labelApellidoApellido2_Click(object sender, EventArgs e)
        {

        }

        private void labelEstatusEstatus_Click(object sender, EventArgs e)
        {

        }

        private void labelFecha2_Click(object sender, EventArgs e)
        {

        }

        private void buttonGestionarContactos2_Click(object sender, EventArgs e)
        {
            var formContacto = new FormContacto();
            formContacto.Show();
        }

        private void buttonListasDifusion2_Click(object sender, EventArgs e)
        {
            // Pasa el nombre del usuario actual al formulario FormListaDifusion
            var formListas = new FormListaDifusion(usuario.Nombre);
            formListas.Show();
        }

        private void buttonMantenimientoListas_Click(object sender, EventArgs e)
        {
            var formMantenimientoListaUsuario = new FormMantenimientoListaUsuario();
            formMantenimientoListaUsuario.Show();
        }
    }
}
