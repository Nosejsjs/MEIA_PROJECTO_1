﻿namespace MEIA_PROYECTO_1
{
    partial class FormRegistro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelUsuario3 = new Label();
            labelNombre3 = new Label();
            labelApellido3 = new Label();
            labelContraseña3 = new Label();
            labelFechaNacimiento3 = new Label();
            labelTelefono3 = new Label();
            textBoxUsuario3 = new TextBox();
            textBoxNombre3 = new TextBox();
            textBoxApellido3 = new TextBox();
            textBoxContraseña3 = new TextBox();
            textBoxFechaNacimiento3 = new TextBox();
            textBoxTelefono3 = new TextBox();
            buttonGuardarUsuario3 = new Button();
            SuspendLayout();
            // 
            // labelUsuario3
            // 
            labelUsuario3.AutoSize = true;
            labelUsuario3.Location = new Point(44, 39);
            labelUsuario3.Name = "labelUsuario3";
            labelUsuario3.Size = new Size(50, 15);
            labelUsuario3.TabIndex = 0;
            labelUsuario3.Text = "Usuario:";
            // 
            // labelNombre3
            // 
            labelNombre3.AutoSize = true;
            labelNombre3.Location = new Point(44, 90);
            labelNombre3.Name = "labelNombre3";
            labelNombre3.Size = new Size(54, 15);
            labelNombre3.TabIndex = 1;
            labelNombre3.Text = "Nombre:";
            // 
            // labelApellido3
            // 
            labelApellido3.AutoSize = true;
            labelApellido3.Location = new Point(44, 138);
            labelApellido3.Name = "labelApellido3";
            labelApellido3.Size = new Size(54, 15);
            labelApellido3.TabIndex = 2;
            labelApellido3.Text = "Apellido:";
            // 
            // labelContraseña3
            // 
            labelContraseña3.AutoSize = true;
            labelContraseña3.Location = new Point(44, 184);
            labelContraseña3.Name = "labelContraseña3";
            labelContraseña3.Size = new Size(70, 15);
            labelContraseña3.TabIndex = 3;
            labelContraseña3.Text = "Contraseña:";
            // 
            // labelFechaNacimiento3
            // 
            labelFechaNacimiento3.AutoSize = true;
            labelFechaNacimiento3.Location = new Point(44, 236);
            labelFechaNacimiento3.Name = "labelFechaNacimiento3";
            labelFechaNacimiento3.Size = new Size(200, 15);
            labelFechaNacimiento3.TabIndex = 4;
            labelFechaNacimiento3.Text = "Fecha de Nacimiento (dd/mm/aaaa)";
            // 
            // labelTelefono3
            // 
            labelTelefono3.AutoSize = true;
            labelTelefono3.Location = new Point(44, 283);
            labelTelefono3.Name = "labelTelefono3";
            labelTelefono3.Size = new Size(55, 15);
            labelTelefono3.TabIndex = 5;
            labelTelefono3.Text = "Telefono:";
            // 
            // textBoxUsuario3
            // 
            textBoxUsuario3.Location = new Point(47, 59);
            textBoxUsuario3.Name = "textBoxUsuario3";
            textBoxUsuario3.Size = new Size(114, 23);
            textBoxUsuario3.TabIndex = 6;

            // 
            // textBoxNombre3
            // 
            textBoxNombre3.Location = new Point(44, 112);
            textBoxNombre3.Name = "textBoxNombre3";
            textBoxNombre3.Size = new Size(117, 23);
            textBoxNombre3.TabIndex = 7;

            // 
            // textBoxApellido3
            // 
            textBoxApellido3.Location = new Point(44, 158);
            textBoxApellido3.Name = "textBoxApellido3";
            textBoxApellido3.Size = new Size(117, 23);
            textBoxApellido3.TabIndex = 8;

            // 
            // textBoxContraseña3
            // 
            textBoxContraseña3.Location = new Point(44, 202);
            textBoxContraseña3.Name = "textBoxContraseña3";
            textBoxContraseña3.Size = new Size(117, 23);
            textBoxContraseña3.TabIndex = 9;

            // 
            // textBoxFechaNacimiento3
            // 
            textBoxFechaNacimiento3.Location = new Point(44, 254);
            textBoxFechaNacimiento3.Name = "textBoxFechaNacimiento3";
            textBoxFechaNacimiento3.Size = new Size(117, 23);
            textBoxFechaNacimiento3.TabIndex = 10;

            // 
            // textBoxTelefono3
            // 
            textBoxTelefono3.Location = new Point(44, 301);
            textBoxTelefono3.Name = "textBoxTelefono3";
            textBoxTelefono3.Size = new Size(117, 23);
            textBoxTelefono3.TabIndex = 11;

            // 
            // buttonGuardarUsuario3
            // 
            buttonGuardarUsuario3.Location = new Point(59, 364);
            buttonGuardarUsuario3.Name = "buttonGuardarUsuario3";
            buttonGuardarUsuario3.Size = new Size(75, 38);
            buttonGuardarUsuario3.TabIndex = 12;
            buttonGuardarUsuario3.Text = "Guardar Usuario";
            buttonGuardarUsuario3.UseVisualStyleBackColor = true;
            buttonGuardarUsuario3.Click += buttonGuardarUsuario3_Click;
            // 
            // FormRegistro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(255, 450);
            Controls.Add(buttonGuardarUsuario3);
            Controls.Add(textBoxTelefono3);
            Controls.Add(textBoxFechaNacimiento3);
            Controls.Add(textBoxContraseña3);
            Controls.Add(textBoxApellido3);
            Controls.Add(textBoxNombre3);
            Controls.Add(textBoxUsuario3);
            Controls.Add(labelTelefono3);
            Controls.Add(labelFechaNacimiento3);
            Controls.Add(labelContraseña3);
            Controls.Add(labelApellido3);
            Controls.Add(labelNombre3);
            Controls.Add(labelUsuario3);
            Name = "FormRegistro";
            Text = "Registro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelUsuario3;
        private Label labelNombre3;
        private Label labelApellido3;
        private Label labelContraseña3;
        private Label labelFechaNacimiento3;
        private Label labelTelefono3;
        private TextBox textBoxUsuario3;
        private TextBox textBoxNombre3;
        private TextBox textBoxApellido3;
        private TextBox textBoxContraseña3;
        private TextBox textBoxFechaNacimiento3;
        private TextBox textBoxTelefono3;
        private Button buttonGuardarUsuario3;
    }
}