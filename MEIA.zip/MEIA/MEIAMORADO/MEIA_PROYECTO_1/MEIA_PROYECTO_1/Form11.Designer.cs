﻿namespace MEIA_PROYECTO_1
{
    partial class FormModificarLista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxNuevoNombre11 = new TextBox();
            textBoxNuevaDesc11 = new TextBox();
            comboBoxEstatus = new ComboBox();
            labelNombre11 = new Label();
            labelDesc11 = new Label();
            labelEstatus11 = new Label();
            buttonModificar11 = new Button();
            SuspendLayout();
            // 
            // textBoxNuevoNombre11
            // 
            textBoxNuevoNombre11.Location = new Point(145, 11);
            textBoxNuevoNombre11.Margin = new Padding(3, 2, 3, 2);
            textBoxNuevoNombre11.Name = "textBoxNuevoNombre11";
            textBoxNuevoNombre11.Size = new Size(110, 23);
            textBoxNuevoNombre11.TabIndex = 0;
            // 
            // textBoxNuevaDesc11
            // 
            textBoxNuevaDesc11.Location = new Point(145, 40);
            textBoxNuevaDesc11.Margin = new Padding(3, 2, 3, 2);
            textBoxNuevaDesc11.Name = "textBoxNuevaDesc11";
            textBoxNuevaDesc11.Size = new Size(110, 23);
            textBoxNuevaDesc11.TabIndex = 1;
            // 
            // comboBoxEstatus
            // 
            comboBoxEstatus.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxEstatus.FormattingEnabled = true;
            comboBoxEstatus.Items.AddRange(new object[] { "Activo", "Inactivo" });
            comboBoxEstatus.Location = new Point(145, 64);
            comboBoxEstatus.Margin = new Padding(3, 2, 3, 2);
            comboBoxEstatus.Name = "comboBoxEstatus";
            comboBoxEstatus.Size = new Size(110, 23);
            comboBoxEstatus.TabIndex = 2;
            // 
            // labelNombre11
            // 
            labelNombre11.AutoSize = true;
            labelNombre11.Location = new Point(21, 16);
            labelNombre11.Name = "labelNombre11";
            labelNombre11.Size = new Size(90, 15);
            labelNombre11.TabIndex = 3;
            labelNombre11.Text = "Nuevo nombre:";
            // 
            // labelDesc11
            // 
            labelDesc11.AutoSize = true;
            labelDesc11.Location = new Point(21, 40);
            labelDesc11.Name = "labelDesc11";
            labelDesc11.Size = new Size(108, 15);
            labelDesc11.TabIndex = 4;
            labelDesc11.Text = "Nueva descripcion:";
            // 
            // labelEstatus11
            // 
            labelEstatus11.AutoSize = true;
            labelEstatus11.Location = new Point(21, 63);
            labelEstatus11.Name = "labelEstatus11";
            labelEstatus11.Size = new Size(85, 15);
            labelEstatus11.TabIndex = 5;
            labelEstatus11.Text = "Nuevo estatus:";
            // 
            // buttonModificar11
            // 
            buttonModificar11.Location = new Point(97, 118);
            buttonModificar11.Margin = new Padding(3, 2, 3, 2);
            buttonModificar11.Name = "buttonModificar11";
            buttonModificar11.Size = new Size(82, 22);
            buttonModificar11.TabIndex = 6;
            buttonModificar11.Text = "modificar";
            buttonModificar11.UseVisualStyleBackColor = true;
            buttonModificar11.Click += buttonModificar11_Click;
            // 
            // FormModificarLista
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(284, 172);
            Controls.Add(buttonModificar11);
            Controls.Add(labelEstatus11);
            Controls.Add(labelDesc11);
            Controls.Add(labelNombre11);
            Controls.Add(comboBoxEstatus);
            Controls.Add(textBoxNuevaDesc11);
            Controls.Add(textBoxNuevoNombre11);
            Margin = new Padding(3, 2, 3, 2);
            Name = "FormModificarLista";
            Text = "FormModificarLista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxNuevoNombre11;
        private TextBox textBoxNuevaDesc11;
        private ComboBox comboBoxEstatus;
        private Label labelNombre11;
        private Label labelDesc11;
        private Label labelEstatus11;
        private Button buttonModificar11;
    }
}