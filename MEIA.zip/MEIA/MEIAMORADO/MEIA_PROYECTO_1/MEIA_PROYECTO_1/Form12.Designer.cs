﻿namespace MEIA_PROYECTO_1
{
    partial class FormListasUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelLista12 = new Label();
            textBoxNombreListaDif12 = new TextBox();
            buttonCargarLista12 = new Button();
            labelAsociar12 = new Label();
            labelEliminarUsuario12 = new Label();
            textBoxAsociar12 = new TextBox();
            textBoxEliminar12 = new TextBox();
            buttonAsociar12 = new Button();
            buttonEliminar12 = new Button();
            labelModificar12 = new Label();
            labelBuscar12 = new Label();
            textBoxBuscar12 = new TextBox();
            buttonModificar12 = new Button();
            buttonBuscar12 = new Button();
            textBoxModificar12 = new TextBox();
            SuspendLayout();
            // 
            // labelLista12
            // 
            labelLista12.AutoSize = true;
            labelLista12.Location = new Point(10, 7);
            labelLista12.Name = "labelLista12";
            labelLista12.Size = new Size(156, 15);
            labelLista12.TabIndex = 0;
            labelLista12.Text = "Nombre de lista de difusion:";
            // 
            // textBoxNombreListaDif12
            // 
            textBoxNombreListaDif12.Location = new Point(188, 4);
            textBoxNombreListaDif12.Margin = new Padding(3, 2, 3, 2);
            textBoxNombreListaDif12.Name = "textBoxNombreListaDif12";
            textBoxNombreListaDif12.Size = new Size(110, 23);
            textBoxNombreListaDif12.TabIndex = 1;
            // 
            // buttonCargarLista12
            // 
            buttonCargarLista12.Location = new Point(303, 4);
            buttonCargarLista12.Margin = new Padding(3, 2, 3, 2);
            buttonCargarLista12.Name = "buttonCargarLista12";
            buttonCargarLista12.Size = new Size(82, 22);
            buttonCargarLista12.TabIndex = 2;
            buttonCargarLista12.Text = "Cargar";
            buttonCargarLista12.UseVisualStyleBackColor = true;
            // 
            // labelAsociar12
            // 
            labelAsociar12.AutoSize = true;
            labelAsociar12.Location = new Point(10, 64);
            labelAsociar12.Name = "labelAsociar12";
            labelAsociar12.Size = new Size(124, 15);
            labelAsociar12.TabIndex = 3;
            labelAsociar12.Text = "Asociar usuario a lista:";
            // 
            // labelEliminarUsuario12
            // 
            labelEliminarUsuario12.AutoSize = true;
            labelEliminarUsuario12.Location = new Point(10, 90);
            labelEliminarUsuario12.Name = "labelEliminarUsuario12";
            labelEliminarUsuario12.Size = new Size(147, 15);
            labelEliminarUsuario12.TabIndex = 4;
            labelEliminarUsuario12.Text = "Eliminar usuario de la lista:";
            // 
            // textBoxAsociar12
            // 
            textBoxAsociar12.Location = new Point(192, 62);
            textBoxAsociar12.Margin = new Padding(3, 2, 3, 2);
            textBoxAsociar12.Name = "textBoxAsociar12";
            textBoxAsociar12.Size = new Size(110, 23);
            textBoxAsociar12.TabIndex = 5;
            // 
            // textBoxEliminar12
            // 
            textBoxEliminar12.Location = new Point(190, 88);
            textBoxEliminar12.Margin = new Padding(3, 2, 3, 2);
            textBoxEliminar12.Name = "textBoxEliminar12";
            textBoxEliminar12.Size = new Size(110, 23);
            textBoxEliminar12.TabIndex = 6;
            // 
            // buttonAsociar12
            // 
            buttonAsociar12.Location = new Point(317, 62);
            buttonAsociar12.Margin = new Padding(3, 2, 3, 2);
            buttonAsociar12.Name = "buttonAsociar12";
            buttonAsociar12.Size = new Size(82, 22);
            buttonAsociar12.TabIndex = 7;
            buttonAsociar12.Text = "Asociar";
            buttonAsociar12.UseVisualStyleBackColor = true;
            buttonAsociar12.Click += buttonAsociar12_Click;
            // 
            // buttonEliminar12
            // 
            buttonEliminar12.Location = new Point(317, 87);
            buttonEliminar12.Margin = new Padding(3, 2, 3, 2);
            buttonEliminar12.Name = "buttonEliminar12";
            buttonEliminar12.Size = new Size(82, 22);
            buttonEliminar12.TabIndex = 8;
            buttonEliminar12.Text = "Eliminar";
            buttonEliminar12.UseVisualStyleBackColor = true;
            buttonEliminar12.Click += buttonEliminar12_Click;
            // 
            // labelModificar12
            // 
            labelModificar12.AutoSize = true;
            labelModificar12.Location = new Point(10, 115);
            labelModificar12.Name = "labelModificar12";
            labelModificar12.Size = new Size(152, 15);
            labelModificar12.TabIndex = 9;
            labelModificar12.Text = "Modificar usuario de la lista";
            // 
            // labelBuscar12
            // 
            labelBuscar12.AutoSize = true;
            labelBuscar12.Location = new Point(10, 140);
            labelBuscar12.Name = "labelBuscar12";
            labelBuscar12.Size = new Size(139, 15);
            labelBuscar12.TabIndex = 10;
            labelBuscar12.Text = "Buscar usuario de la lista:";
            // 
            // textBoxBuscar12
            // 
            textBoxBuscar12.Location = new Point(188, 142);
            textBoxBuscar12.Margin = new Padding(3, 2, 3, 2);
            textBoxBuscar12.Name = "textBoxBuscar12";
            textBoxBuscar12.Size = new Size(110, 23);
            textBoxBuscar12.TabIndex = 12;
            // 
            // buttonModificar12
            // 
            buttonModificar12.Location = new Point(317, 115);
            buttonModificar12.Margin = new Padding(3, 2, 3, 2);
            buttonModificar12.Name = "buttonModificar12";
            buttonModificar12.Size = new Size(82, 22);
            buttonModificar12.TabIndex = 13;
            buttonModificar12.Text = "Modificar";
            buttonModificar12.UseVisualStyleBackColor = true;
            // 
            // buttonBuscar12
            // 
            buttonBuscar12.Location = new Point(317, 142);
            buttonBuscar12.Margin = new Padding(3, 2, 3, 2);
            buttonBuscar12.Name = "buttonBuscar12";
            buttonBuscar12.Size = new Size(82, 22);
            buttonBuscar12.TabIndex = 14;
            buttonBuscar12.Text = "Buscar";
            buttonBuscar12.UseVisualStyleBackColor = true;
            buttonBuscar12.Click += buttonBuscar12_Click_1;
            // 
            // textBoxModificar12
            // 
            textBoxModificar12.Location = new Point(188, 118);
            textBoxModificar12.Margin = new Padding(3, 2, 3, 2);
            textBoxModificar12.Name = "textBoxModificar12";
            textBoxModificar12.Size = new Size(110, 23);
            textBoxModificar12.TabIndex = 11;
            // 
            // FormListasUsuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(412, 211);
            Controls.Add(buttonBuscar12);
            Controls.Add(buttonModificar12);
            Controls.Add(textBoxBuscar12);
            Controls.Add(textBoxModificar12);
            Controls.Add(labelBuscar12);
            Controls.Add(labelModificar12);
            Controls.Add(buttonEliminar12);
            Controls.Add(buttonAsociar12);
            Controls.Add(textBoxEliminar12);
            Controls.Add(textBoxAsociar12);
            Controls.Add(labelEliminarUsuario12);
            Controls.Add(labelAsociar12);
            Controls.Add(buttonCargarLista12);
            Controls.Add(textBoxNombreListaDif12);
            Controls.Add(labelLista12);
            Margin = new Padding(3, 2, 3, 2);
            Name = "FormListasUsuario";
            Text = "FormListasUsuario";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelLista12;
        private TextBox textBoxNombreListaDif12;
        private Button buttonCargarLista12;
        private Label labelAsociar12;
        private Label labelEliminarUsuario12;
        private TextBox textBoxAsociar12;
        private TextBox textBoxEliminar12;
        private Button buttonAsociar12;
        private Button buttonEliminar12;
        private Label labelModificar12;
        private Label labelBuscar12;
        private TextBox textBoxBuscar12;
        private Button buttonModificar12;
        private Button buttonBuscar12;
        private TextBox textBoxModificar12;
    }
}