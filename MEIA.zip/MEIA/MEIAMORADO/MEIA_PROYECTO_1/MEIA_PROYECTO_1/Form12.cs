﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MEIA_PROYECTO_1
{
    public partial class FormListasUsuario : Form
    {
        private const string RutaListas = "C:/MEIA/listas.txt";
        private const string RutaListaUsuarios = "C:/MEIA/lista_usuario.txt";
        private const string RutaIndiceListaUsuarios = "C:/MEIA/indice_lista_usuario.txt";
        private const string RutaUsuarios = "C:/MEIA/user.txt"; // Ruta del archivo de usuarios

        public FormListasUsuario()
        {
            InitializeComponent();
        }

        // Método para verificar si una lista existe en el archivo "listas.txt"
        private bool ListaExiste(string nombreLista)
        {
            // Leer todas las líneas del archivo "listas.txt" y verificar si la lista existe
            var listas = File.ReadLines(RutaListas)
                             .Select(linea => linea.Split(';')[0])  // Obtener el nombre de la lista (la primera columna)
                             .ToList();

            return listas.Contains(nombreLista);
        }

        // Método para verificar si un usuario existe en el archivo "user.txt"
        private bool UsuarioExiste(string usuario)
        {
            // Leer todas las líneas del archivo "user.txt" y verificar si el usuario existe
            var usuarios = File.ReadLines(RutaUsuarios)
                                .Select(linea => linea.Split(';')[0])  // Obtener el nombre de usuario (la primera columna)
                                .ToList();

            return usuarios.Contains(usuario);
        }

        // Botón para asociar usuario a la lista
        private void buttonAsociar12_Click(object sender, EventArgs e)
        {
            string nombreLista = textBoxNombreListaDif12.Text;
            string usuarioCreador = "admin"; // Obtén el usuario logeado si es necesario
            string usuarioAsociado = textBoxAsociar12.Text;
            string fechaCreacion = DateTime.Now.ToString();
            string estatus = "1"; // Activo

            // Validar que la lista exista antes de continuar
            if (!ListaExiste(nombreLista))
            {
                MessageBox.Show("La lista especificada no existe. No se puede asociar usuarios.");
                return;
            }

            if (string.IsNullOrEmpty(usuarioAsociado))
            {
                MessageBox.Show("Ingrese el usuario a asociar.");
                return;
            }

            // Verificar si el usuario existe en el archivo "user.txt"
            if (!UsuarioExiste(usuarioAsociado))
            {
                MessageBox.Show("El usuario no existe en el sistema.");
                return;
            }

            // Formato del registro en el archivo principal
            string nuevoRegistro = $"{nombreLista}|{usuarioCreador}|{usuarioAsociado}|{fechaCreacion}|{estatus}";
            File.AppendAllText(RutaListaUsuarios, nuevoRegistro + Environment.NewLine);

            // Actualizar el índice
            string[] lineasIndice = File.ReadAllLines(RutaIndiceListaUsuarios);
            int nuevoRegistroId = lineasIndice.Length + 1;
            string nuevaEntradaIndice = $"{nuevoRegistroId}|{nuevoRegistroId - 1}.0|{nombreLista}|{usuarioCreador}|{usuarioAsociado}|{fechaCreacion}|{estatus}";
            File.AppendAllText(RutaIndiceListaUsuarios, nuevaEntradaIndice + Environment.NewLine);

            // Actualizar el número de usuarios en listas.txt
            var listas = File.ReadAllLines(RutaListas).ToList();
            var listaIndex = listas.FindIndex(linea => linea.Split(';')[0] == nombreLista);
            if (listaIndex != -1)
            {
                var listaDatos = listas[listaIndex].Split(';');
                int numUsuarios = int.Parse(listaDatos[3]);
                listaDatos[3] = (numUsuarios + 1).ToString(); // Incrementar el número de usuarios
                listas[listaIndex] = string.Join(";", listaDatos);
                File.WriteAllLines(RutaListas, listas);
            }

            MessageBox.Show("Usuario asociado a la lista correctamente.");
        }

        // Botón para eliminar usuario de la lista
        private void buttonEliminar12_Click(object sender, EventArgs e)
        {
            string nombreLista = textBoxNombreListaDif12.Text;
            string usuarioAsociado = textBoxEliminar12.Text;

            // Validar que la lista exista antes de continuar
            if (!ListaExiste(nombreLista))
            {
                MessageBox.Show("La lista especificada no existe. No se puede eliminar usuarios.");
                return;
            }

            if (string.IsNullOrEmpty(usuarioAsociado))
            {
                MessageBox.Show("Ingrese el usuario a eliminar.");
                return;
            }

            // Verificar si el usuario está en el archivo "lista_usuario.txt" y está asociado a la lista indicada
            var registros = File.ReadAllLines(RutaListaUsuarios).ToList();
            bool usuarioExiste = false;

            for (int i = 0; i < registros.Count; i++)
            {
                var campos = registros[i].Split('|');
                // Verificar si el nombre de la lista y el usuario coinciden
                if (campos[0] == nombreLista && campos[2] == usuarioAsociado && campos[4] == "1") // Estatus activo
                {
                    usuarioExiste = true;
                    campos[4] = "0"; // Cambiar estatus a inactivo
                    registros[i] = string.Join("|", campos);
                    break;
                }
            }

            if (!usuarioExiste)
            {
                MessageBox.Show("El usuario no está asociado a la lista o ya está inactivo.");
                return; // Si el usuario no existe o ya está inactivo, no hacemos nada
            }

            // Guardar los cambios en el archivo de usuarios
            File.WriteAllLines(RutaListaUsuarios, registros);

            // Actualizar el índice también
            var lineasIndice = File.ReadAllLines(RutaIndiceListaUsuarios).ToList();
            bool usuarioIndiceExiste = false;

            for (int i = 0; i < lineasIndice.Count; i++)
            {
                var campos = lineasIndice[i].Split('|');
                // Verificar si el nombre de la lista y el usuario coinciden en el índice
                if (campos[2] == nombreLista && campos[4] == usuarioAsociado && campos[6] == "1") // Estatus activo
                {
                    usuarioIndiceExiste = true;
                    campos[6] = "0"; // Cambiar estatus a inactivo
                    lineasIndice[i] = string.Join("|", campos);
                    break;
                }
            }

            if (!usuarioIndiceExiste)
            {
                MessageBox.Show("No se encontró el usuario en el índice o ya está inactivo.");
                return; // Si el usuario no está en el índice o ya está inactivo, no procedemos con la eliminación
            }

            // Guardar los cambios en el archivo de índice
            File.WriteAllLines(RutaIndiceListaUsuarios, lineasIndice);

            // Actualizar el número de usuarios en listas.txt
            var listas = File.ReadAllLines(RutaListas).ToList();
            var listaIndex = listas.FindIndex(linea => linea.Split(';')[0] == nombreLista);

            if (listaIndex != -1)
            {
                var listaDatos = listas[listaIndex].Split(';');
                int numUsuarios = int.Parse(listaDatos[3]);
                listaDatos[3] = (numUsuarios - 1).ToString(); // Decrementar el número de usuarios
                listas[listaIndex] = string.Join(";", listaDatos);
                File.WriteAllLines(RutaListas, listas);
            }

            MessageBox.Show("Usuario eliminado de la lista correctamente.");
        }

        // Botón para modificar usuario en la lista
        private void buttonModificar12_Click(object sender, EventArgs e)
        {
            string nombreLista = textBoxNombreListaDif12.Text;
            string usuarioAsociado = textBoxModificar12.Text;

            // Validar que la lista exista antes de continuar
            if (!ListaExiste(nombreLista))
            {
                MessageBox.Show("La lista especificada no existe. No se puede modificar usuarios.");
                return;
            }

            if (string.IsNullOrEmpty(usuarioAsociado))
            {
                MessageBox.Show("Ingrese el usuario a modificar.");
                return;
            }

            // Modificar los datos en el archivo principal y el índice
            var registros = File.ReadAllLines(RutaListaUsuarios).ToList();
            for (int i = 0; i < registros.Count; i++)
            {
                var campos = registros[i].Split('|');
                if (campos[0] == nombreLista && campos[2] == usuarioAsociado)
                {
                    // Aquí puedes realizar modificaciones en otros campos
                    campos[4] = "1"; // Reactivarlo o actualizar otro campo
                    registros[i] = string.Join("|", campos);
                    break;
                }
            }
            File.WriteAllLines(RutaListaUsuarios, registros);

            MessageBox.Show("Usuario modificado en la lista.");
        }

        // Botón para buscar usuario en la lista
        // Botón para buscar usuario en la lista
        private void buttonBuscar12_Click(object sender, EventArgs e)
        {
            string nombreLista = textBoxNombreListaDif12.Text;
            string usuarioAsociado = textBoxBuscar12.Text;

            if (string.IsNullOrEmpty(usuarioAsociado))
            {
                MessageBox.Show("Ingrese el usuario a buscar.");
                return;
            }

            var registros = File.ReadLines(RutaListaUsuarios);
            var registroEncontrado = registros.FirstOrDefault(linea =>
                linea.Split('|')[0] == nombreLista && linea.Split('|')[2] == usuarioAsociado);

            if (registroEncontrado != null)
            {
                MessageBox.Show($"Registro encontrado:\n{registroEncontrado}");
            }
            else
            {
                MessageBox.Show("Usuario no encontrado en la lista.");
            }
        }

        private void buttonBuscar12_Click_1(object sender, EventArgs e)
        {
            string nombreLista = textBoxBuscar12.Text;

            if (string.IsNullOrEmpty(nombreLista))
            {
                MessageBox.Show("Ingrese el nombre de la lista a buscar.");
                return;
            }

            // Leer el archivo de lista_usuario.txt para encontrar los usuarios asociados a la lista específica
            var registrosUsuarios = File.ReadLines(RutaListaUsuarios)
                .Where(linea => linea.Split('|')[0] == nombreLista && linea.Split('|')[4] == "1") // Filtrar por nombre de lista y estado activo
                .Select(linea => linea.Split('|'));  // Separar por '|' para obtener los datos individuales

            if (registrosUsuarios.Any())
            {
                // Crear el mensaje con la información de los usuarios de forma ordenada
                string mensajeUsuarios = "Usuarios activos asociados a la lista:\n\n";
                foreach (var usuario in registrosUsuarios)
                {
                    string usuarioAsociado = usuario[2]; // Usuario asociado
                    string fechaAsociacion = usuario[3]; // Fecha de asociación
                    mensajeUsuarios += $"Usuario: {usuarioAsociado}\nFecha de Asociación: {fechaAsociacion}\n\n";
                }

                // Mostrar la información en un cuadro de mensaje
                MessageBox.Show(mensajeUsuarios, "Usuarios Asociados");
            }
            else
            {
                MessageBox.Show("No hay usuarios activos asociados a esta lista.");
            }
        }
    }
}
